Follow these steps, dummy!

1) Copy dashify.pl to your 'plugins' folder (inside your mt3
   folder).

2) Change your archive paths to use dashify="1" instead of 
   dirify="1".

3) Rebuild your weblog.

4) Profit!


----------------------------------------------------------------------
(C)2004 Cal Henderson, <cal@iamcal.com>
