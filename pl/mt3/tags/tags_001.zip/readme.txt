Follow these steps, dummy!

1) Copy the file into your 'plugins' folder (inside your mt3
   folder).

2) Add some keywords to a post.

3) Profit!


----------------------------------------------------------------------
(C)2004 Cal Henderson, <cal@iamcal.com>
