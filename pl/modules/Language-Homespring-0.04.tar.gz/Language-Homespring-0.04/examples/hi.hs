Universe marshy now. The marshy stuff evaporates downstream. Sense
rapids
upstream. Killing. Device downstream. Sense shallows and say Hi,. 
   That powers the     force. Field sense shallows hatchery power.
Hi .. What's. your. name?. 
  Hydro. Power spring  when snowmelt then       powers
    insulated bear hatchery !.
 Powers felt;       powers feel     snowmelt themselves.
