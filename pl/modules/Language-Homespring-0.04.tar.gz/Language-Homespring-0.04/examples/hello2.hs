universe bear hatchery Hello,. world!.
 powers   marshy marshy snowmelt
