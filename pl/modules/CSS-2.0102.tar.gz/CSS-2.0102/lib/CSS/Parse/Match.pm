package CSS::Parse::Match;

use strict;
use warnings;

sub new {
	my ($class, $op, $tokens) = @_;

	my $self = bless {}, $class;

	$self->{op}		= $op;
	$self->{submatches}	= [];
	$self->{matched_tokens}	= [];
	$self->{tokens}		= [];
	$self->{subrule}	= undef;

	push @{$self->{tokens}}, $_ for @{$tokens};

	return $self;
}

sub add_submatch {
	my ($self, $submatch) = @_;

	push @{$self->{submatches}}, $submatch;

	$self->{tokens} = $submatch->{tokens};
}

sub add_matched_token {
	my ($self, $token) = @_;

	push @{$self->{matched_tokens}}, $token;
}

sub shift_token {
	return shift @{$_[0]->{tokens}};
}

sub unshift_token {
	unshift @{$_[0]->{tokens}}, $_[1];
}

sub scrub {
	my ($self) = @_;

	delete $self->{tokens};
	delete $self->{op};

	for my $submatch (@{$self->{submatches}}){

		$submatch->scrub;
	}
}

sub dump {
	my ($self) = @_;

	return $self->dump_internal('');
}

sub dump_internal {
	my ($self, $prefix) = @_;

	my $subs = scalar @{$self->{submatches}};
	my $matches = scalar @{$self->{matched_tokens}};

	return '' unless $subs || $matches;

	my $text = $self->dump_node_text;

	my $buffer = "$prefix$self->{op} \"$text\" \{\n";

	for my $submatch (@{$self->{submatches}}){

		$buffer .= $submatch->dump_internal("$prefix\t");
	}

	for my $token (@{$self->{matched_tokens}}){

		$buffer .= "$prefix\t$token->{type}: \"$token->{content}\"\n";
	}

	$buffer .= "$prefix}\n";

	return $buffer;
}

sub dump_node_text {
	my ($self) = @_;

	my $buffer = '';

	for my $submatch (@{$self->{submatches}}){

		$buffer .= $submatch->dump_node_text;
	}

	for my $token (@{$self->{matched_tokens}}){

		$buffer .= $token->{content};
	}

	return $buffer;
}

sub reduce {
	my ($self) = @_;

	#
	# first reduce our own submatches
	#

	my $subrules = 0;

	for my $submatch (@{$self->{submatches}}){

		$submatch->reduce;

		if (defined $submatch->{subrule}){

			$subrules++;
		}
	}


	#
	# remove any submatches which don't match any content
	#

	my $old_submatches = $self->{submatches};
	$self->{submatches} = [];

	for my $submatch (@{$old_submatches}){

		if (length $submatch->{matched_text}){

			push @{$self->{submatches}}, $submatch;
		}
	}

	


	#
	# collect together our output
	#

	$self->{matched_text} = '';

	for my $token (@{$self->{matched_tokens}}){

		$self->{matched_text} .= $token->{content};
	}

	# this line is a bit dodgy as it deletes the original token list which we *may* want
	delete $self->{matched_tokens};

	for my $submatch (@{$self->{submatches}}){

		$self->{matched_text} .= $submatch->{matched_text};
	}


	#
	# now reduce ourselves.
	# if all of our submatches are not subrules, fold them into ourselves
	#

	unless ($subrules){

		my $old_submatches = $self->{submatches};
		$self->{submatches} = [];

		for my $submatch (@{$old_submatches}){

			for my $subsubmatch (@{$submatch->{submatches}}){

				push @{$self->{submatches}}, $subsubmatch;
			}

			for my $subtoken (@{$submatch->{matched_tokens}}){

				push @{$self->{matched_tokens}}, $subtoken;
			}
		}
	}}

1;
