package CSS::Ruleset;

use strict;
use warnings;

sub new {
	my ($class) = @_;
	my $self = bless {}, $class;

	$self->{selector} = '';
	$self->{selectors} = [];
	$self->{declarations} = [];

	$self->{properties} = $self->{declarations};

	return $self;
}

sub match_selector {
	my ($self, $name) = @_;

	for my $selector (@{$self->{selectors}}){

		if ($selector->{name} eq $name){

			return 1;
		}
	}

	return 0;
}

sub get_property_by_name {

	return get_declaration_by_name(@_);
}

sub get_declaration_by_name {
	my ($self, $name) = @_;

	for my $declaration (@{$self->{declarations}}){

		if ($declaration->{property} eq $name){

			return $declaration;
		}
	}

	return undef;
}


1;