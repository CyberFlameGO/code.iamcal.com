package CSS::Grammar::CSS10;

use strict;
use warnings;

use base 'CSS::Grammar';
	
1;
