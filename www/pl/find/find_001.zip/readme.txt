INSTALLATION
------------

* Install perl
* Copy find.pl to C:\
* If your perl binary isn't in C:\perl\bin\perl.exe then edit find.reg in notepad
* Run find.reg


USAGE
-----

* Right-click on a folder and choose "Perl Search"
* Enter your search string
* To use a perl style regular expresssion, enter it between slashes, eg. /test\d{4}/
* Hit enter - results are displayed with paths relative to the base folder
* Search is recursive!
* Hit enter again to close the results window
