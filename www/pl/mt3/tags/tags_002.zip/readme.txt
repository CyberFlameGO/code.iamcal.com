Follow these steps, dummy!

1) Copy the file into your 'plugins' folder (inside your mt3
   folder).

2) Add some keywords to a post.

3) Profit!


4) To convert previous keywords into tags, copy the mt-retag.cgi
   file into you mt folder, adjust the path-to-perl is needed,
   chmod to 755 and access via the web. (warning: it'll take a
   while to run - running it from the command line is a good 
   idea if you can).

----------------------------------------------------------------------
(C)2004 Cal Henderson, <cal@iamcal.com>
