package CSS::Grammar::CSS30;

use strict;
use warnings;

use base 'CSS::Grammar';

1;
