package CSS;

$VERSION = 1.00;

use strict;
use warnings;

use Carp;
use CSS::Style;
use CSS::Selector;
use CSS::Property;
use CSS::Adaptor;

use Data::Dumper;

sub new {
	my $class = shift;
	my $self = bless {}, $class;

	my $options = shift;
	$self->{styles} = [];
	$self->{parser} = $options->{parser} || 'CSS::Parse::Lite';

	return $self;
}

sub adaptor {  #not a real adaptor, just a scalar for style to create adaptor objects
	my $self = shift;
	my $option = shift;
	return $self->{adaptor} unless $option;

	$self->{adaptor} = $option;
}

sub read_file {
	my $self = shift;
	my $path = shift;

	if (ref $path){
		if (ref $path eq 'ARRAY'){
			$self->read_file($_) for @$path;
			return 1;
		}
	} else {
 		if ($path){
			local *IN;
 			open(IN, $path) or croak "couldn't open file: $!";
			my $source = join '',<IN>;
			close(IN);
			$self->parse_string($source) if $source;
			return 1;
		}
	}
	croak "only scalars and arrays accepted: $!";
}

sub read_string {
	my $self = shift;
	my $data = shift;
	$self->parse_string($data) if length $data;
}

sub parse_string {
	my $self = shift;
	my $string = shift;

	# remove spaces and comments now
#	$string =~ tr/\n\t/  /;
	$string =~ s!/\*.*?\*\/!!g;
	$string =~ s|<!--||g;
	$string =~ s|-->||g;

	eval "use $self->{parser}";
	my $parser_obj = new $self->{parser};
	$parser_obj->{'parent'} = $self;
	$parser_obj->parse_string($string);
}

sub purge {
	my $self = shift;
	$self->{styles} = [];
}

1;
__END__

=head1 NAME

CSS - Perl Object oriented access to Cascading Style Sheets (CSS)

=head1 SYNOPSIS

  use CSS;

  # create a CSS object with the default options  
  my $css = CSS->new();

  # create a CSS object with a specific parser
  my $css = CSS->new({'parser' => 'CSS::Parse::Lite'});
  my $css = CSS->new({'parset' => 'CSS::Parse::Heavy'});

=head1 DESCRIPTION

Toto: re-write this text

=head1 METHODS

Todo: re-write this text

=head2 CONSTRUCTOR

Only one constructor: new(). An optional hash can contain arguments:

  parser	module to use as the CSS parser

=head2 ACCESSORS

  read_file( $filename ) or read_file( @filenames )

  read_string( $scalar )

=head1 AUTHORS

Copyright (C) 2001-2002, Allen Day <allenday@ucla.edu>

Copyright (C) 2003, Cal Henderson <cal@iamcal.com>

=head1 SEE ALSO

L<CSS::Style>, L<CSS::Selector>, L<CSS::Property>, L<CSS::PropertyValue>, 
L<CSS::Parse::Lite>, L<CSS::Parse::Heavy>, L<CSS::Parse::Compiled>, perl(1)

=cut
