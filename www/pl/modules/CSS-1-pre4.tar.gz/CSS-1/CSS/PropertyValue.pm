package CSS::PropertyValue;

$VERSION = 1.00;

use strict;
use warnings;

sub new {
	my $class = shift;
	my $self = bless {}, $class;
	return $self;
}

