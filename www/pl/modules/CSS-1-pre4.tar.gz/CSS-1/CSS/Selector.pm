package CSS::Selector;

$VERSION = 1.00;

use strict;
use warnings;


sub new {
	my $class = shift;
	my $self = bless {}, $class;

	$self->{name} = shift;

	return $self;
}

