package CSS::Property;

$VERSION = 1.00;

use strict;
use warnings;

sub new {
	my $class = shift;
	my $self = bless {}, $class;

	$self->{property} = shift;
	$self->{value} = shift;

	return $self;
}

