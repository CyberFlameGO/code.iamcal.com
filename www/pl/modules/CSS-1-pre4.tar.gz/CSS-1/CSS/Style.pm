package CSS::Style;

$VERSION = 1.00;

use strict;
use warnings;

# create a new CSS::Style object
sub new {
	my $class = shift;
	my $self = bless {}, $class;

	$self->{selectors} = [];
	$self->{properties} = [];

	return $self;
}

sub add_selector {
	my $self = shift;
	my $selector = shift;

	push @{$self->{selectors}}, $selector;
}

sub add_property {
	my $self = shift;
	my $property = shift;

	push @{$self->{properties}}, $property;
}

1;
