package CSS;

use strict;
use warnings;

our $VERSION = 2.01_01;

sub new {
	my $class = shift;
	my $self = bless {}, $class;

	my %opts = (ref $_[0]) ? ((ref $_[0] eq 'HASH') ? %{$_[0]} : () ) : @_;

	$self->{atrules}  = [];
	$self->{rulesets} = [];
	$self->{items}    = [];
	$self->{sheets}   = [];

	$self->{styles} = $self->{rulesets};

	$self->{grammar} = $opts{grammar} || 'CSS21';
	$self->{adaptor} = $opts{adaptor} || 'CSS::Adaptor';

	return $self;
}

sub read_file {
	my ($self, $path) = @_;

	if (ref $path){
		if (ref $path eq 'ARRAY'){
			$self->read_file($_) for @$path;
			return 1;
		}
	} else {
 		if ($path){
			local *IN;
 			open(IN, $path) or die "Couldn't open file: $!";
			my $source = join '',<IN>;
			close(IN);
			$self->parse_string($source) if $source;
			return 1;
		}
	}
	die "Only scalars and arrays accepted: $!";
}

sub read_string {
	my ($self, $data) = @_;

	if (ref $data){
		if (ref $data eq 'ARRAY'){
			$self->read_string($_) for @$data;
			return 1;
		}
	} else {
		$self->parse_string($data) if length $data;
	}
}

sub parse_string {
	my ($self, $string) = @_;

	use CSS::Grammar::Core;

	my $grammar = new CSS::Grammar::Core;


	#
	# tokenize input string
	#

	my $tokens = $grammar->toke($string);

	unless (defined $tokens){

		die "Can't tokenize input string";
	}


	#
	# build a match tree
	#

	my $tree = $grammar->lex($tokens);

	unless (defined $tree){

		die "Can't lex token stream";
	}


	#
	# 'reduce' the match tree into subrules
	#

	$tree->reduce;

	unless (defined $tree){

		die "Can't reduce match tree";
	}


	#
	# walk the match tree and generate a sheet
	#

	my $sheet = $grammar->walk($tree);

	unless (defined $sheet){

		die "Can't walk the match tree";
	}


	#
	# merge the resultant sheet with the CSS object
	#

	$self->merge_sheet($sheet);
}

sub purge {
	my ($self) = @_;

	$self->{atrules}  = [];
	$self->{rulesets} = [];
	$self->{items}    = [];
	$self->{sheets}   = [];

	$self->{styles} = $self->{rulesets};
}

sub set_adaptor {
	my $self = shift;
	my $adaptor = shift;

	$self->{adaptor} = $adaptor;

	for(@{$self->{styles}}){
		$_->set_adaptor($adaptor);
	}
}

sub output {
	my $self = shift;
	my $adaptor = shift || $self->{adaptor};

	for(@{$self->{styles}}){
		$_->set_adaptor($adaptor);
	}

	my $output = '';
	for(@{$self->{styles}}){
		$output .= "$_";
	}

	return $output;
}

sub get_style_by_selector {

	return get_ruleset_by_selector(@_);
}

sub get_ruleset_by_selector {
	my ($self, $sel_name) = @_;

	for my $ruleset (@{$self->{rulesets}}){

		return $ruleset if $ruleset->match_selector($sel_name);
	}

	return undef;
}

sub merge_sheet {
	my ($self, $stylesheet) = @_;

	for my $item (@{$stylesheet->{items}}){

		push @{$self->{items}}, $item;
		push @{$self->{atrules}}, $item if ref $item eq 'CSS::AtRule';
		push @{$self->{rulesets}}, $item if ref $item eq 'CSS::Ruleset';
	}

	push @{$self->{sheets}}, $stylesheet;
}

1;

__END__

=head1 NAME

CSS - A CSS parser

=head1 SYNOPSIS

  use CSS;

=head1 DESCRIPTION

...

=head1 METHODS

=over

=item C<new( option => $value )>

This constructor returns ...

=back

=head1 AUTHOR

Copyright (C) 2001-2002, Allen Day <allenday@ucla.edu>

Copyright (C) 2003-2006, Cal Henderson <cal@iamcal.com>

=head1 SEE ALSO

L<CSS::AtRule>

=cut
