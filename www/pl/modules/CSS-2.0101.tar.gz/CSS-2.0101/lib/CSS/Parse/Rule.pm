package CSS::Parse::Rule;

use strict;
use warnings;

use CSS::Parse::Op;

sub new {
 	my ($class, $grammar, $name, $rule) = @_;
	my $self = bless {}, $class;

	$self->{error} = 0;
	$self->{grammar} = $grammar;
	$self->{name} = $name;

	$self->parse($rule) if defined $rule;

	return $self;
}

sub parse {
	my ($self, $rule) = @_;

	$self->{error} = 0;
	$self->{rule} = $rule;


	# now try and tokenise the rule
	# we first tokenise it, and *then* split it into alternations,
	# since finding the pipes will be tricky if they occur inside
	# literals or character classes

	my $ops = [];

	$rule =~ s/^\s+//;

	while($rule){
		my $op = undef;

		if ($rule =~ m!^\[!){

			$op = CSS::Parse::Op->new($self, 'group start');
			$rule = substr $rule, 1;

		}elsif ($rule =~ m!^\]!){

			$op = CSS::Parse::Op->new($self, 'group end');
			$rule = substr $rule, 1;

		}elsif ($rule =~ m!^([a-z_][a-z_0-9-]*)!i){

			$op = CSS::Parse::Op->new($self, 'subrule', $1);
			$rule = substr $rule, length $1;

		}elsif ($rule =~ m!^\*!){

			$op = CSS::Parse::Op->new($self, 'rep star');
			$rule = substr $rule, 1;

		}elsif ($rule =~ m!^\+!){

			$op = CSS::Parse::Op->new($self, 'rep plus');
			$rule = substr $rule, 1;

		}elsif ($rule =~ m!^\?!){

			$op = CSS::Parse::Op->new($self, 'rep quest');
			$rule = substr $rule, 1;

		}elsif ($rule =~ m!^\|!){

			$op = CSS::Parse::Op->new($self, 'alt');
			$rule = substr $rule, 1;

		}else{

			$self->{error} = "Couldn't parse op at start of $rule";
			return;
		}

		push @{$ops}, $op;

		$rule =~ s/^\s+//;
	}

	#
	# first we create a base op (of type list)
	# which will represent a list of ops for this rule
	#

	my $base = CSS::Parse::Op->new($self, 'list');
	$base->{ops} = $ops;

	$self->{base} = $base;


	#
	# now we create a node tree from the flat list
	#

	return unless $self->produce_groups($base);


	#
	# and perform recursive cleanups
	#

	unless ($base->reduce_alternations()){
		$self->{error} = $base->{error};
		return;
	}

	unless ($base->reduce_repetition()){
		$self->{error} = $base->{error};
		return;
	}

	unless ($base->reduce_empty()){
		$self->{error} = $base->{error};
		return;
	}
}

sub produce_groups {
	my ($self, $base) = @_;

	my $ops = $base->{ops};
	$base->{ops} = [];
	my $current = $base;

	while(my $op = shift @{$ops}){

		if ($op->{type} eq 'group start'){

			my $parent = CSS::Parse::Op->new($self, 'list');
			$parent->{parent} = $current;
			$parent->{ops} = [];

			push @{$current->{ops}}, $parent;

			$current = $parent;

		}elsif ($op->{type} eq 'group end'){

			$current = $current->{parent};

			if (!defined($current)){
				$self->{error} = "end of group found without matching begin in rule $self->{rule}";
				return 0;
			}

		}else{
			push @{$current->{ops}}, $op;
		}

	}

	return 1;
}

sub has_error {
	my ($self) = @_;
	return $self->{error} ? 1 : 0;
}

sub error {
	my ($self) = @_;
	return $self->{error} ? $self->{error} : '';
}

sub base_op {
	my ($self) = @_;
	return $self->{base};
}

sub match {
	my ($self, $tokens) = @_;

	#
	# given a list of input tokens ($tokens) we
	# try to create a tree of match objects to
	# return, else we return undef
	#

	my $ret = $self->base_op->match($tokens);

	$ret->{subrule} = $self->{name} if defined $ret;

	return $ret;
}

sub find_rule {
	my ($self, $rule_name) = @_;

	return $self->{grammar}->find_rule($rule_name);
}

1;
