package CSS::Grammar;

use strict;
use warnings;

use CSS::Parse::Rule;
use Time::HiRes qw(gettimeofday tv_interval);

sub new {
	my ($class) = @_;
	my $self = bless {}, $class;

	$self->{toke_rules} = {};
	$self->{toke_order} = [];
	$self->{case_insensitive} = 0;
	$self->{base_rule} = '';
	$self->{lex_rules} = {};
	$self->{error} = '';

	$self->init();

	return $self;
}

sub init {
	my ($self) = @_;
}

sub add_toke_rule {
	my ($self, $name, $rx) = @_;

	$self->{error} = '';

	if ($self->{case_insensitive}){

		$self->{toke_rules}->{$name} = qr/^($rx)/is;
	}else{
		$self->{toke_rules}->{$name} = qr/^($rx)/s;
	}

	push @{$self->{toke_order}}, $name;
}

sub add_lex_rule {
	my ($self, $name, $rule_source) = @_;

	$self->{error} = '';

	my $rule = CSS::Parse::Rule->new($self, $name, $rule_source);

	if ($rule->{error}){
		$self->{error} = $rule->{error};
		return 0;
	}

	$self->{lex_rules}->{$name} = $rule;
	return 1;
}

sub toke {
	my ($self, $input) = @_;

	$self->{error} = '';

	my $tokens = [];

	while(length $input){

		my $matched = 0;

		for my $rule(@{$self->{toke_order}}){

			#my $match_start = [gettimeofday];

			if ($input =~ $self->{toke_rules}->{$rule}){

				#$self->{time_match} += tv_interval($match_start, [gettimeofday]);

				#my $push_start = [gettimeofday];
				push @{$tokens}, CSS::Token->new($rule, $1);
				#$self->{time_push} += tv_interval($push_start, [gettimeofday]);

				#my $substr_start = [gettimeofday];
				$input = substr $input, length $1;
				#$self->{time_substr} += tv_interval($substr_start, [gettimeofday]);

				$matched = 1;

				last;
			}

			#$self->{time_no_match} += tv_interval($match_start, [gettimeofday]);
		}

		unless ($matched){

			push @{$tokens}, CSS::Token->new('MISC', substr $input, 0, 1);
			$input = substr $input, 1;
		}
	}

	return $tokens;
}

sub lex {
	my ($self, $input) = @_;

	$self->{error} = '';

	my $rule = $self->{lex_rules}->{$self->{base_rule}};

	return undef unless defined $rule;

	my $match = $rule->match($input, 0);

	return undef unless defined $match;

	my $leftover = $match->tokens_left;

	if ($leftover){

		$self->{error} = "Lexer didn't match all tokens with base rule ($leftover left over)\n";
	}

	return $match;
}

sub set_base {
	my ($self, $base_rule) = @_;

	$self->{base_rule} = $base_rule;
}

sub find_rule {
	my ($self, $rule_name) = @_;

	return $self->{lex_rules}->{$rule_name};
}

	
package CSS::Token;

sub new {
	my ($class, $type, $content) = @_;
	my $self = bless {}, $class;

	$self->{type} = $type;
	$self->{content} = $content;

	return $self;
}

1;
