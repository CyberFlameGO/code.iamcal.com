package CSS::Parse::Rule::Trace;

use base 'CSS::Parse::Rule';

sub match {
	my $self = shift;

	print "Starting to match $self->{name}\n" if $self->{trace_in};

	my $ret = $self->SUPER::match(@_);

	print "Ending match on $self->{name} (".(defined $ret ? 'MATCHED' : 'no match').")\n" if $self->{trace_out};

	return $ret;
}

1;