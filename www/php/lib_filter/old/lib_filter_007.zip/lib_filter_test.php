<?php
	#
	# $Id: lib_filter_test.php,v 1.3 2004/11/02 17:03:00 cal Exp $
	#

	include("lib_filter.php");
	include("test_harness.php");


	# basics
	filter_harness("","");
	filter_harness("hello","hello");

	# balancing tags
	filter_harness("<b>hello","<b>hello</b>");
	filter_harness("hello<b>","hello");
	filter_harness("hello<b>world","hello<b>world</b>");
	filter_harness("hello</b>","hello");
	filter_harness("hello<b/>","hello");
	filter_harness("hello<b/>world","hello<b>world</b>");
	filter_harness("<b><b><b>hello","<b><b><b>hello</b></b></b>");
	filter_harness("</b><b>","");

	# end slashes
	filter_harness('<img>','<img />');
	filter_harness('<img/>','<img />');
	filter_harness('<b/></b>','');

	# balancing angle brakets
	filter_harness('<img src="foo"','<img src="foo" />');
	filter_harness('b>','');
	filter_harness('b>hello','<b>hello</b>');
	filter_harness('<img src="foo"/','<img src="foo" />');
	filter_harness('>','');
	filter_harness('hello<b','hello');
	filter_harness('b>foo','<b>foo</b>');
	filter_harness('><b','');
	filter_harness('b><','');
	filter_harness('><b>','');

	# attributes
	filter_harness('<img src=foo>','<img src="foo" />');
	filter_harness('<img asrc=foo>','<img />');
	filter_harness('<img src=test test>','<img src="test" />');

	# non-allowed tags
	filter_harness('<script>','');
	filter_harness('<script','');
	filter_harness('<script/>','');
	filter_harness('</script>','');
	filter_harness('<script woo=yay>','');
	filter_harness('<script woo="yay">','');
	filter_harness('<script woo="yay>','');
	filter_harness('<script woo="yay<b>','');
	filter_harness('<script woo="yay<b>hello','<b>hello</b>');
	filter_harness('<script<script>>','');
	filter_harness('<<script>script<script>>','script');
	filter_harness('<<script><script>>','');
	filter_harness('<<script>script>>','');
	filter_harness('<<script<script>>','');

	# bad protocols
	filter_harness('<a href="http://foo">bar</a>', '<a href="http://foo">bar</a>');
	filter_harness('<a href="ftp://foo">bar</a>', '<a href="ftp://foo">bar</a>');
	filter_harness('<a href="mailto:foo">bar</a>', '<a href="mailto:foo">bar</a>');
	filter_harness('<a href="javascript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'."\t".'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'."\n".'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'.chr(1).'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="jscript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="vbscript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="view-source:foo">bar</a>', '<a href="#foo">bar</a>');

	# self-closing tags
	filter_harness('<img src="a">', '<img src="a" />');
	filter_harness('<img src="a">foo</img>', '<img src="a" />foo');
	filter_harness('</img>', '');

	# typos
	filter_harness('<b>test<b/>', '<b>test</b>');
	filter_harness('<b/>test<b/>', '<b>test</b>');
	filter_harness('<b/>test', '<b>test</b>');

	# case conversion
	case_harness('hello world', 'hello world');
	case_harness('Hello world', 'Hello world');
	case_harness('Hello World', 'Hello World');
	case_harness('HELLO World', 'HELLO World');
	case_harness('HELLO WORLD', 'Hello world');
	case_harness('<b>HELLO WORLD', '<b>Hello world');
	case_harness('<B>HELLO WORLD', '<B>Hello world');
	case_harness('HELLO. WORLD', 'Hello. World');
	case_harness('HELLO<b> WORLD', 'Hello<b> World');

	# comments
	$filter->strip_comments = 0;
	filter_harness('hello <!-- foo --> world', 'hello <!-- foo --> world');
	filter_harness('hello <!-- <foo --> world', 'hello <!-- &lt;foo --> world');
	filter_harness('hello <!-- foo> --> world', 'hello <!-- foo&gt; --> world');
	filter_harness('hello <!-- <foo> --> world', 'hello <!-- &lt;foo&gt; --> world');

	$filter->strip_comments = 1;
	filter_harness('hello <!-- foo --> world', 'hello  world');
	filter_harness('hello <!-- <foo --> world', 'hello  world');
	filter_harness('hello <!-- foo> --> world', 'hello  world');
	filter_harness('hello <!-- <foo> --> world', 'hello  world');


	function filter_harness($in, $out){
		$got = $GLOBALS[filter]->go($in);
		test_harness($in, $out, $got, "Filter test ".++$GLOBALS[tests][filter]);
	}

	function case_harness($in, $out){
		$got = $GLOBALS[filter]->fix_case($in);
		test_harness($in, $out, $got, "Case test ".++$GLOBALS[tests][filter_case]);
	}

?>