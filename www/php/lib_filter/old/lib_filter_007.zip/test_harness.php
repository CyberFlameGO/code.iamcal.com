<?php
	#
	# A simple PHP test harness
	#
	# $Id: test_harness.php,v 1.1 2004/09/24 20:28:14 Cal Henderson Exp $
	#
	# (C)2001-2004 Cal Henderson <cal@iamcal.com>
	#

	$GLOBALS[tests] = array();
	$GLOBALS[verbose] = $GLOBALS[HTTP_GET_VARS][verbose];

	function test_harness($in, $out, $got, $name){

		echo "$name : ";
		if ($out == $got){
			echo "<span style=\"color: green;\">pass</span>";
		}else{
			echo "<span style=\"color: red; font-weight: bold;\">fail</span>";
		}
		if ($GLOBALS[verbose] || ($out != $got)){
			echo " (<b>in:</b> ".htmlentities($in)." <b>expected:</b> ".htmlentities($out)." <b>got:</b> ".htmlentities($got).")";
		}
		echo "<br>\n";
	}

?>