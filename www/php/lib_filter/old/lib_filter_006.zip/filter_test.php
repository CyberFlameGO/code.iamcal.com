<?php
	include("lib_filter.txt");


	# basics
	filter_harness("","");
	filter_harness("hello","hello");

	# balancing tags
	filter_harness("<b>hello","<b>hello</b>");
	filter_harness("hello<b>","hello");
	filter_harness("hello<b>world","hello<b>world</b>");
	filter_harness("hello</b>","hello");
	filter_harness("hello<b/>","hello");
	filter_harness("hello<b/>world","hello<b>world</b>");
	filter_harness("<b><b><b>hello","<b><b><b>hello</b></b></b>");
	filter_harness("</b><b>","");

	# end slashes
	filter_harness('<img>','<img />');
	filter_harness('<img/>','<img />');
	filter_harness('<b/></b>','');

	# balancing angle brakets
	filter_harness('<img src="foo"','<img src="foo" />');
	filter_harness('b>','');
	filter_harness('b>hello','<b>hello</b>');
	filter_harness('<img src="foo"/','<img src="foo" />');
	filter_harness('>','');
	filter_harness('hello<b','hello');
	filter_harness('b>foo','<b>foo</b>');
	filter_harness('><b','');
	filter_harness('b><','');
	filter_harness('><b>','');

	# attributes
	filter_harness('<img src=foo>','<img src="foo" />');
	filter_harness('<img asrc=foo>','<img />');
	filter_harness('<img src=test test>','<img src="test" />');

	# non-allowed tags
	filter_harness('<script>','');
	filter_harness('<script','');
	filter_harness('<script/>','');
	filter_harness('</script>','');
	filter_harness('<script woo=yay>','');
	filter_harness('<script woo="yay">','');
	filter_harness('<script woo="yay>','');
	filter_harness('<script woo="yay<b>','');
	filter_harness('<script woo="yay<b>hello','<b>hello</b>');
	filter_harness('<script<script>>','');
	filter_harness('<<script>script<script>>','script');
	filter_harness('<<script><script>>','');
	filter_harness('<<script>script>>','');
	filter_harness('<<script<script>>','');

	# bad protocols
	filter_harness('<a href="http://foo">bar</a>', '<a href="http://foo">bar</a>');
	filter_harness('<a href="ftp://foo">bar</a>', '<a href="ftp://foo">bar</a>');
	filter_harness('<a href="mailto:foo">bar</a>', '<a href="mailto:foo">bar</a>');
	filter_harness('<a href="javascript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'."\t".'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'."\n".'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="java'.chr(1).'script:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="jscript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="vbscript:foo">bar</a>', '<a href="#foo">bar</a>');
	filter_harness('<a href="view-source:foo">bar</a>', '<a href="#foo">bar</a>');

	# self-closing tags
	filter_harness('<img src="a">', '<img src="a" />');
	filter_harness('<img src="a">foo</img>', '<img src="a" />foo');
	filter_harness('</img>', '');

	# typos
	filter_harness('<b>test<b/>', '<b>test</b>');
	filter_harness('<b/>test<b/>', '<b>test</b>');
	filter_harness('<b/>test', '<b>test</b>');



	function filter_harness($in, $out){
		global $tests, $filter;

		$tests[filter]++;
		$got = $filter->go($in);
		basic_harness($in, $out, $got, "Filter test $tests[filter]");
	}

	function basic_harness($in, $out, $got, $name){
		global $verbose;

		echo "$name : ";
		if ($out == $got){
			echo "<span style=\"color: green;\">pass</span>";
		}else{
			echo "<span style=\"color: red; font-weight: bold;\">fail</span>";
		}
		if ($verbose || ($out != $got)){
			echo " (<b>in:</b> ".htmlentities($in)." <b>expected:</b> ".htmlentities($out)." <b>got:</b> ".htmlentities($got).")";
		}
		echo "<br>\n";
	}

?>