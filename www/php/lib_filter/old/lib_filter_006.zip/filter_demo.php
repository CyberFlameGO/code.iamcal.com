<?php
	#
	# include the filter library
	#

	include_once("lib_filter.txt");


	#
	# set tags and attributes we'll allows
	#

	$filter->allowed = array(
		'a' => array('href', 'target'),
		'b' => array(),
		'img' => array('src', 'width', 'height', 'alt'),
	);


	#
	# set tags that don't have an end tag - they'll be closed implicitly
	#

	$filter->no_close = array(
		'img',
	);


	#
	# set attributes that will have the protocol filtered
	#

	$filter->protocol_attributes = array(
		'src',
		'href',
	);


	#
	# set the list of allowed protocols
	#

	$filter->allowed_protocols = array(
		'http',
		'ftp',
		'mailto',
	);


	#
	# use the filter
	#

	$input = '<a foo="bar" href="baz">quxx</a>';

	$output = $filter->go($input);

	echo htmlentities($output);

?>