# phpMyAdmin SQL Dump
# version 2.5.6
# http://www.phpmyadmin.net
#
# Host: localhost
# Generation Time: May 18, 2004 at 07:06 PM
# Server version: 4.0.18
# PHP Version: 4.3.6
# 
# Database : `share`
# 

# --------------------------------------------------------

#
# Table structure for table `share_acl_perms`
#

CREATE TABLE `share_acl_perms` (
  `id` int(11) NOT NULL auto_increment,
  `acl_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=25 ;

#
# Dumping data for table `share_acl_perms`
#

INSERT INTO `share_acl_perms` VALUES (22, 2, 7, 0);
INSERT INTO `share_acl_perms` VALUES (24, 1, 6, 0);

# --------------------------------------------------------

#
# Table structure for table `share_acls`
#

CREATE TABLE `share_acls` (
  `id` int(11) NOT NULL auto_increment,
  `mode` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=29 ;

#
# Dumping data for table `share_acls`
#

INSERT INTO `share_acls` VALUES (1, 1);
INSERT INTO `share_acls` VALUES (2, 1);
INSERT INTO `share_acls` VALUES (7, 0);
INSERT INTO `share_acls` VALUES (8, 1);
INSERT INTO `share_acls` VALUES (11, 0);
INSERT INTO `share_acls` VALUES (12, 0);

# --------------------------------------------------------

#
# Table structure for table `share_files`
#

CREATE TABLE `share_files` (
  `id` int(11) NOT NULL auto_increment,
  `folder_id` varchar(255) NOT NULL default '',
  `filename` varchar(255) NOT NULL default '',
  `filename_on_disk` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `user_id` int(11) NOT NULL default '0',
  `date_create` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=20 ;

#
# Dumping data for table `share_files`
#


# --------------------------------------------------------

#
# Table structure for table `share_folders`
#

CREATE TABLE `share_folders` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `write_acl_id` int(11) NOT NULL default '0',
  `read_acl_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=15 ;

#
# Dumping data for table `share_folders`
#

INSERT INTO `share_folders` VALUES (1, 0, 'Test Folder', '', 2, 1);
INSERT INTO `share_folders` VALUES (4, 0, 'Public Readable Folder', '', 8, 7);
INSERT INTO `share_folders` VALUES (6, 0, 'Public Writable Folder', '', 12, 11);

# --------------------------------------------------------

#
# Table structure for table `share_group_members`
#

CREATE TABLE `share_group_members` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=20 ;

#
# Dumping data for table `share_group_members`
#

INSERT INTO `share_group_members` VALUES (13, 6, 10);
INSERT INTO `share_group_members` VALUES (14, 7, 8);
INSERT INTO `share_group_members` VALUES (12, 6, 9);
INSERT INTO `share_group_members` VALUES (11, 6, 8);
INSERT INTO `share_group_members` VALUES (10, 6, 11);
INSERT INTO `share_group_members` VALUES (18, 8, 8);
INSERT INTO `share_group_members` VALUES (16, 7, 9);
INSERT INTO `share_group_members` VALUES (17, 7, 10);
INSERT INTO `share_group_members` VALUES (19, 8, 10);

# --------------------------------------------------------

#
# Table structure for table `share_groups`
#

CREATE TABLE `share_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=9 ;

#
# Dumping data for table `share_groups`
#

INSERT INTO `share_groups` VALUES (8, 'Some Users');
INSERT INTO `share_groups` VALUES (7, 'All Users');
INSERT INTO `share_groups` VALUES (6, 'Users & Admins');

# --------------------------------------------------------

#
# Table structure for table `share_icons`
#

CREATE TABLE `share_icons` (
  `id` int(11) NOT NULL auto_increment,
  `filename` varchar(255) NOT NULL default '',
  `extension` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=6 ;

#
# Dumping data for table `share_icons`
#

INSERT INTO `share_icons` VALUES (1, 'zip.gif', 'zip');
INSERT INTO `share_icons` VALUES (2, 'image.gif', 'jpg');
INSERT INTO `share_icons` VALUES (3, 'image.gif', 'gif');
INSERT INTO `share_icons` VALUES (4, 'image.gif', 'jpeg');
INSERT INTO `share_icons` VALUES (5, 'word.gif', 'doc');

# --------------------------------------------------------

#
# Table structure for table `share_users`
#

CREATE TABLE `share_users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL default '',
  `password` varchar(255) NOT NULL default '',
  `full_name` varchar(255) NOT NULL default '',
  `admin_delete` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=12 ;

#
# Dumping data for table `share_users`
#

INSERT INTO `share_users` VALUES (10, 'test3', 'test3', 'Test User 3', 0);
INSERT INTO `share_users` VALUES (11, 'admin', 'admin', 'Test Admin', 1);
INSERT INTO `share_users` VALUES (9, 'test2', 'test2', 'Test User 2', 0);
INSERT INTO `share_users` VALUES (8, 'test1', 'test1', 'Test User 1', 0);
