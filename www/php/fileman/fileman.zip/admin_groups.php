<?
	include("init.php");

	if ($remove){
		mysql_query("DELETE FROM share_group_members WHERE id=$remove", $db);
		header("Location: admin_groups.php");
		exit;
	}

	add_nav("Admin", "admin.php");
	add_nav("Group Admin", "admin_groups.php");

	include("head.txt");
?>

<div class="filebox">

<table cellpadding="0" cellspacing="2" border="0">
	<tr>
		<td><a href="admin_group.php"><img src="icons/group.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_group.php">Create a new group</a></td>
	</tr>
</table>
<br>

<table border="1" cellpadding="4" cellspacing="0">
	<tr>
		<td><b>&nbsp;</b></td>
		<td><b>Group Name</b></td>
		<td><b>Users In Group</b></td>
		<td><b>Edit Group</b></td>
	</tr>
<?
	$result = mysql_query("SELECT * FROM share_groups ORDER BY name ASC", $db);
	while($row = mysql_fetch_array($result)){
?>
	<tr valign="top">
		<td><img src="icons/group.gif" width="16" height="16"></td>
		<td><?=htmlentities($row[name])?></td>
		<td>
			<table cellpadding="0" cellspacing="2" border="0">

<?
		$subresult = mysql_query("SELECT m.id, u.full_name FROM share_group_members AS m, share_users AS u WHERE m.group_id=$row[id] AND m.user_id=u.id ORDER BY u.full_name ASC", $db);
		while($subrow = mysql_fetch_array($subresult)){
?>
				<tr>
					<td><img src="icons/user.gif" width="16" height="16" border="0"></td>
					<td><?=$subrow[full_name]?> - <a href="admin_groups.php?remove=<?=$subrow[id]?>">Remove</a></td>
				</tr>
<?
		}
		if (!mysql_num_rows($subresult)){
?>
				<tr>
					<td><img src="icons/user_off.gif" width="16" height="16" border="0"></td>
					<td><i>none</i></td>
				</tr>
<?
		}
?>
				<tr><td colspan="2">&nbsp;</td></tr>
				<tr>
					<td><a href="admin_group_add.php?id=<?=$row[id]?>"><img src="icons/user.gif" width="16" height="16" border="0"></a></td>
					<td><a href="admin_group_add.php?id=<?=$row[id]?>">Add user to group</a></td>
				</tr>
			</table>
		</td>
		<td><a href="admin_group.php?id=<?=$row[id]?>">Edit</a></td>
	</tr>
<?
	}
?>
</table>

</div>

<?
	include("foot.txt");
?>