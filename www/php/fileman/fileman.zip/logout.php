<?
	include("init.php");

	setcookie("fileman_username_cookie", '.', 0, $cfg[cookie_path]);
	setcookie("fileman_password_cookie", '.', 0, $cfg[cookie_path]);
	header("Location: ./");
	exit;
?>
