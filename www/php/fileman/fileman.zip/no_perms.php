<?
	add_nav("Error", $login_url);
	include("head.txt");
?>

<div class="filebox">

	You don't have the necessary permissions to be able to view this folder.<br>
	<br>
	<a href="<?=$login_url?>">Click here</a> to log in as someone else.<br>

</div>

<?
	include("foot.txt");
?>