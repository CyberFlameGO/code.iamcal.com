<?
	include("init.php");

	if ($id){
		$folder_row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id='$id'",$db));
		$children = get_child_folders($folder_row[id]);
	}else{
		$children = array();
		$folder_row = array();
	}

	if ($done){
		if ($id){
			mysql_query("UPDATE share_folders SET name='$name', parent_id='$parent_id' WHERE id='$id'",$db);
		}else{
			create_folder($name, $parent_id);
		}
		header("Location: admin_folders.php");
		exit;
	}

	if ($delete){
		delete_folder($id);
		header("Location: admin_folders.php");
		exit;
	}

	if ($acl_mode){
		mysql_query("UPDATE share_acls SET mode=$value WHERE id=$acl_mode", $db);
		header("Location: admin_folder.php?id=$id");
		exit;
	}

	if ($remove_group){
		mysql_query("DELETE FROM share_acl_perms WHERE group_id=$remove_group AND acl_id=$acl", $db);
		header("Location: admin_folder.php?id=$id");
		exit;
	}

	if ($remove_user){
		mysql_query("DELETE FROM share_acl_perms WHERE user_id=$remove_user AND acl_id=$acl", $db);
		header("Location: admin_folder.php?id=$id");
		exit;
	}

	add_nav("Admin", "admin.php");
	add_nav("Folder Admin", "admin_folders.php");
	add_nav("Edit Folder", "admin_folder.php?id=$id");

	include("head.txt");
?>

<div class="filebox">

<form action="admin_folder.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="done" value="1">

Name:<br>
<input type="text" name="name" value="<?=htmlentities($folder_row[name])?>" class="edit"><br>
<br>

Parent:<br>
<select name="parent_id">
<?
	$s = ($folder_row[parent_id] == 0)?' selected':'';
	echo "<option value=\"0\"$s>None (Top Level Folder)</option>\n";
	$result = mysql_query("SELECT * FROM share_folders ORDER BY name ASC", $db);
	while($row = mysql_fetch_array($result)){
		if (!in_array($row[id], $children)){
			$s = ($folder_row[parent_id] == $row[id])?' selected':'';
			echo "<option value=\"$row[id]\"$s>".get_folder_path($row[id])."</option>\n";
		}
	}
?>
</select><br>
<br>

<input type="submit" value="Save Changes">

</form>

<?
	if ($id){
?>

<br>
<br>

<div class="permsbox">

	<table>
		<tr valign="top">
			<td>
				<b>Read Permissions</b><br>
				<table border="0" cellpadding="4" cellspacing="0">
				<?insert_acl_editor("admin_folder.php?id=$id", $folder_row[read_acl_id])?>
				<tr><td colspan="2">Add exception: <a href="admin_folder_add_group.php?id=<?=$id?>&acl=<?=$folder_row[read_acl_id]?>">Group</a>, <a href="admin_folder_add_user.php?id=<?=$id?>&acl=<?=$folder_row[read_acl_id]?>">User</a></td></tr>
				</table>
			</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td>
				<b>Write Permissions</b><br>
				<table border="0" cellpadding="4" cellspacing="0">
				<?insert_acl_editor("admin_folder.php?id=$id", $folder_row[write_acl_id])?>
				<tr><td colspan="2">Add exception: <a href="admin_folder_add_group.php?id=<?=$id?>&acl=<?=$folder_row[write_acl_id]?>">Group</a>, <a href="admin_folder_add_user.php?id=<?=$id?>&acl=<?=$folder_row[write_acl_id]?>">User</a></td></tr>
				</table>
			</td>
		</tr>
	</table>

	<br>
	<b>A note about permissions:</b><br>
	Only 'allow all' mode accepts users who haven't logged in.
	The 'allow all except...' mode automatically blocks users who haven't logged in.
	To create a folder for all logged in users, either create a group containing all users and set permissions to 'deny all except <i>group</i>', <b>or</b> create a user account you wont use, and then set permissions to 'allow all except <i>user</i>'.
</div>

<br>

<div class="deletebox">
<?
		list($files) = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM share_files WHERE folder_id=$id", $db));
		list($folders) = mysql_fetch_array(mysql_query("SELECT COUNT(*) FROM share_folders WHERE parent_id=$id", $db));
		if ($files || $folders){
?>
	You can not delete this folder - it contains files or sub-folders.
<?
		}else{
?>
	Click the button to delete this folder:<br>
	<br>
	<form action="admin_folder.php" method="post" onsubmit="return sure();">
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="delete" value="1">
	<input type="submit" value="Delete Folder">
	</form>
<?
		}
?>
</div>

<?
	}
?>

</div>

<?
	include("foot.txt");
?>