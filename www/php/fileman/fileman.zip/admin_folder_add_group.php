<?
	include("init.php");

	if ($done && $add_id){
		mysql_query("INSERT INTO share_acl_perms (acl_id, group_id) VALUES ($acl, $add_id)", $db);
		header("Location: admin_folder.php?id=$id");
		exit;
	}

	$acl_data = get_acl($acl);

	add_nav("Admin", "admin.php");
	add_nav("Folder Admin", "admin_folders.php");
	add_nav("Edit Folder", "admin_folder.php?id=$id");
	add_nav("Add Group Permission", "admin_folder_add_group.php?id=$id&acl=$acl");

	include("head.txt");
?>

<div class="filebox">

<?
	$options = array();
	$result = mysql_query("SELECT * FROM share_groups ORDER BY name ASC", $db);
	while($row = mysql_fetch_array($result)){
		if (!in_array($row[id], $acl_data[groups])){
			$options[] = "<option value=\"$row[id]\">".htmlentities($row[name])."</option>\n";
		}
	}
	if (count($options)){
?>

<form action="admin_folder_add_group.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="acl" value="<?=$acl?>">
<input type="hidden" name="done" value="1">

Group:<br>
<select name="add_id">
<?=implode('',$options)?>
</select><br>
<br>

<input type="submit" value="Save Changes">

</form>

<?
	}else{
?>
	There are no more groups to add to this permission list!<br>
	<br>
	<a href="admin_folder.php?id=<?=$id?>">Click here</a> to go back.<br>
<?
	}
?>
</div>

<?
	include("foot.txt");
?>