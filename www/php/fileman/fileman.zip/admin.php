<?
	include("init.php");

	add_nav("Admin", "admin.php");

	include("head.txt");
?>

<div class="filebox">

<table border="0" cellpadding="0" cellspacing="2">
	<tr>
		<td><a href="admin_users.php"><img src="icons/user.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_users.php">User Admin</a></td>
	</tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
		<td><a href="admin_groups.php"><img src="icons/group.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_groups.php">Group Admin</a></td>
	</tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
		<td><a href="admin_folders.php"><img src="icons/folder_small.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_folders.php">Folder Admin</a></td>
	</tr>

	<tr><td colspan="2">&nbsp;</td></tr>
	<tr>
		<td><a href="admin_icons.php"><img src="icons/file_small.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_icons.php">Icon Admin</a></td>
	</tr></table>

</div>

<?
	include("foot.txt");
?>