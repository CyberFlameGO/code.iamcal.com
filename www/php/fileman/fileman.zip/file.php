<?
	include("init.php");

	$file_row = mysql_fetch_array(mysql_query("SELECT * FROM share_files WHERE id='$id'", $db));
	$folder_row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id=$file_row[folder_id]", $db));

	if (!check_permission($cfg[user], $folder_row[read_acl_id])){
		exit;
	}

	if ($delete){
		if (($cfg[user][id] == $file_row[user_id]) || ($cfg[user][admin_delete])){
			# delete the file!
			delete_file($id);
			include("kill_popup.php");
		}
	}

	$icons = load_icon_mappings();
	$ext = get_extension($file_row[filename]);
	$icon = ($icons[$ext])?$icons[$ext]:'icons/file.gif';

	$size = get_filesize($file_row[filename_on_disk]);

	list($username) = mysql_fetch_array(mysql_query("SELECT full_name FROM share_users WHERE id='$file_row[user_id]'", $db));
?>
<html>
<head>
<title>File Manager</title>
<style>

body {
	background-color: #ffffff;
	margin: 5px;
}

.filebox {
	border: 2px solid #cccccc;
	padding: 10px;	
	color: #000000;
	font-family: helvetica, arial, sans-serif;
	font-size: 12px;
}

form {
	padding: 0px;
	margin: 0px;
	border: 0px;
}

.deletebox {
	background-color: #ffcccc;
	padding: 10px;
	border: 2px solid #cc9999;
}

</style>
<script language="Javascript">
<!--

function sure(){
	return window.confirm('Are you sure?');
}

//-->
</script>
</head>
<body>

<div class="filebox">

<div style="float: right;"><a href="Javascript:close();">Close</a></div>
<div>
<br>
<a href="download.php?id=<?=$file_row[id]?>"><img src="<?=$icon?>" width="32" height="32" border="0"></a><br>
<a href="download.php?id=<?=$file_row[id]?>"><b><?=$file_row[filename]?></b></a> (<?=$size?>)<br>
<br>
<?=htmlentities($file_row[description])?><br>
<br>
Posted by <?=$username?>, <?=date('H:i jS F Y',$file_row[date_create])?><br>

<? if (($cfg[user][id] == $file_row[user_id]) || ($cfg[user][admin_delete])){ ?>

<br>
<div class="deletebox">
	Click the button to delete this file:<br>
	<br>
	<form action="file.php" method="post" onsubmit="return sure();">
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="delete" value="1">
	<input type="submit" value="Delete File">
	</form>
</div>

<? } ?>

</div>
</div>

</body>
</html>