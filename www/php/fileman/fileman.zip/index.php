<?
	include("init.php");

	$folder_id = ($folder_id)?$folder_id:0;
	add_folder_path($folder_id);

	$can_upload = 0;
	if ($folder_id){
		$folder_row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id=$folder_id", $db));
		if (!check_permission($cfg[user], $folder_row[read_acl_id])){
			$login_url = "login.php?redir=".urlencode("./?folder_id=$folder_id");
			if ($cfg[user_ok]){
				include("no_perms.php");
			}else{
				header("Location: $login_url");
			}
			exit;
		}
		# only logged in users can upload files
		if ($cfg[user_ok]){
			$can_upload = check_permission($cfg[user], $folder_row[write_acl_id]);
		}
	}

	if ($upload && $can_upload){
		$filename_on_disk = upload_file('thefile');
		if ($filename_on_disk){
			$filename = trim($HTTP_POST_FILES['thefile']['name']);
			$time = time();
			mysql_query("INSERT INTO share_files (folder_id, filename, filename_on_disk, description, user_id, date_create) VALUES ('$folder_id', '$filename', '$filename_on_disk', '$description', '{$cfg[user][id]}', '$time')", $db);
			header("Location: ./?folder_id=$folder_id");
			exit;
		}
	}

	include("head.txt");
?>

<div class="filebox">

<table border="0" cellpadding="4" cellspacing="0">
<?
	$result = mysql_query("SELECT * FROM share_folders WHERE parent_id='$folder_id' ORDER BY name ASC", $db);
	while($row = mysql_fetch_array($result)){

		if (check_permission($cfg[user], $row[read_acl_id])){
?>
	<tr>
		<td><a href="./?folder_id=<?=$row[id]?>"><img src="icons/folder.gif" width="32" height="32" border="0"></a></td>
		<td><a href="./?folder_id=<?=$row[id]?>"><b><?=$row[name]?></b></a><br><?=$row[description]?></td>
	</tr>
<?
		}else{
?>
	<tr>
		<td><img src="icons/folder_off.gif" width="32" height="32" border="0"></td>
		<td><i><b><?=$row[name]?></b><br><?=$row[description]?></i></td>
	</tr>
<?
		}
	}
?>
<?
	$icons = load_icon_mappings();
	$result = mysql_query("SELECT * FROM share_files WHERE folder_id='$folder_id' ORDER BY filename ASC", $db);
	while($row = mysql_fetch_array($result)){
		$ext = get_extension($row[filename]);
		$icon = ($icons[$ext])?$icons[$ext]:'icons/file.gif';
?>
	<tr>
		<td><a href="Javascript:file(<?=$row[id]?>);"><img src="<?=$icon?>" width="32" height="32" border="0"></a></td>
		<td><a href="Javascript:file(<?=$row[id]?>);"><b><?=$row[filename]?></b></a><br><?=htmlentities($row[description])?></td>
	</tr>
<?
	}
	if (!$folder_id){
?>
	<tr>
		<td><a href="admin.php"><img src="icons/admin.gif" width="32" height="32" border="0"></a></td>
		<td><a href="admin.php">Admin</a></td>
	</tr>
<?
	}
?>
</table>

<? if ($can_upload){ ?>

<br>
<br>
<div class="uploadbox">
	<form action="./" method="post" enctype="multipart/form-data">
	<input type="hidden" name="upload" value="1">
	<input type="hidden" name="folder_id" value="<?=$folder_id?>">

	<b>Upload a file into this folder</b><br>
	<br>

	File:<br>
	<input type="file" name="thefile"><br>
	<br>

	Description:<br>
	<input type="text" name="description" class="edit"><br>
	<br>

	<input type="submit" value="Upload">

	</form>
</div>

<? } ?>

</div>

<?
	include("foot.txt");
?>