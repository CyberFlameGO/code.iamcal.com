<?
	include("init.php");

	add_nav("Admin", "admin.php");
	add_nav("Folder Admin", "admin_folders.php");

	include("head.txt");
?>

<div class="filebox">

<table cellpadding="0" cellspacing="2" border="0">
	<tr>
		<td><a href="admin_folder.php"><img src="icons/folder_small.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_folder.php">Create a new folder</a></td>
	</tr>
</table>
<br>

<table border="1" cellpadding="4" cellspacing="0">
	<tr>
		<td><b>&nbsp;</b></td>
		<td><b>Folder Name</b></td>
		<td><b>Read Permissions</b></td>
		<td><b>Write Permissions</b></td>
		<td><b>Edit</b></td>
	</tr>
<?
	function insert_folders($parent_id){
		global $db;
		$result = mysql_query("SELECT * FROM share_folders WHERE parent_id=$parent_id ORDER BY name ASC", $db);
		while($row = mysql_fetch_array($result)){
?>
	<tr valign="top">
		<td><img src="icons/folder_small.gif" width="16" height="16"</td>
		<td><?=get_folder_path($row[id])?></td>
		<td><?show_acl($row[read_acl_id])?></td>
		<td><?show_acl($row[write_acl_id])?></td>
		<td><a href="admin_folder.php?id=<?=$row[id]?>">Edit</a></td>
	</tr>
<?
			insert_folders($row[id]);
		}
	}
	insert_folders(0);
?>
</table>

</div>

<?
	include("foot.txt");
?>