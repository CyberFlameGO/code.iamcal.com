<?
	include("init.php");

	if ($id){
		$user_row = mysql_fetch_array(mysql_query("SELECT * FROM share_groups WHERE id=$id",$db));
	}else{
		$user_row = array();
	}

	if ($done){
		if ($id){
			mysql_query("UPDATE share_groups SET name='$name' WHERE id=$id", $db);
		}else{
			mysql_query("INSERT INTO share_groups (name) VALUES ('$name')", $db);
		}
		header("Location: admin_groups.php");
		exit;
	}

	if ($delete){
		delete_group($id);
		header("Location: admin_groups.php");
		exit;
	}

	add_nav("Admin", "admin.php");
	add_nav("Group Admin", "admin_groups.php");
	add_nav("Edit Group", "admin_group.php?id=$id");

	include("head.txt");
?>

<div class="filebox">

<form action="admin_group.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="done" value="1">

Name:<br>
<input type="text" name="name" value="<?=htmlentities($user_row[name])?>" class="edit"><br>
<br>

<input type="submit" value="Save Changes">

</form>

<? if ($id){ ?>
<br>
<br>
<div class="deletebox">
	Click the button to delete this group:<br>
	<br>
	<form action="admin_group.php" method="post" onsubmit="return sure();">
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="delete" value="1">
	<input type="submit" value="Delete Group">
	</form>
</div>

<? } ?>

</div>


<?
	include("foot.txt");
?>