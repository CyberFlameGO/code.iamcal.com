<?
	include("init.php");

	$file_row = mysql_fetch_array(mysql_query("SELECT * FROM share_files WHERE id='$id'", $db));
	$folder_row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id=$file_row[folder_id]", $db));

	if (!check_permission($cfg[user], $folder_row[read_acl_id])){
		exit;
	}

	$mime = 'application/unknown';

	# push out the file
	header("Content-Disposition: attachment; filename=$file_row[filename]");
	header("Content-type: $mime; name=$file_row[filename]");
	header("Pragma: no-cache");
	header("Expires: 0");

	$fp = fopen("$cfg[files_path]/$file_row[filename_on_disk]","rb");
	fpassthru($fp);
	flush();
	exit;


?>