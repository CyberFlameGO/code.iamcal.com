<?
	include("init.php");

	add_nav("Admin", "admin.php");
	add_nav("Icon Admin", "admin_icons.php");

	include("head.txt");
?>

<div class="filebox">

<table cellpadding="0" cellspacing="2" border="0">
	<tr>
		<td><a href="admin_icon.php"><img src="icons/file_small.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_icon.php">Create a new icon mapping</a></td>
	</tr>
</table>
<br>

<table border="1" cellpadding="4" cellspacing="0">
	<tr>
		<td><b>Icon</b></td>
		<td><b>File Extension</b></td>
		<td><b>Edit</b></td>
	</tr>
<?
	$result = mysql_query("SELECT * FROM share_icons ORDER BY extension ASC", $db);
	while($row = mysql_fetch_array($result)){
?>
	<tr>
		<td><img src="custom_icons/<?=$row[filename]?>" width="32" height="32"></td>
		<td>*.<?=htmlentities($row[extension])?></td>
		<td><a href="admin_icon.php?id=<?=$row[id]?>">edit</a></td>
	</tr>
<?
	}
?>
</table>

</div>

<?
	include("foot.txt");
?>