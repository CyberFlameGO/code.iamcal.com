<?
	include("init.php");

	if ($id){
		$user_row = mysql_fetch_array(mysql_query("SELECT * FROM share_users WHERE id=$id",$db));
	}else{
		$user_row = array();
	}

	if ($done){
		$admin_delete = ($admin_delete)?1:0;
		if ($id){
			mysql_query("UPDATE share_users SET username='$username', password='$password', full_name='$full_name', admin_delete='$admin_delete' WHERE id=$id", $db);
		}else{
			mysql_query("INSERT INTO share_users (username, password, full_name, admin_delete) VALUES ('$username', '$password', '$full_name', '$admin_delete')", $db);
		}
		header("Location: admin_users.php");
		exit;
	}

	if ($delete){
		delete_user($id);
		header("Location: admin_users.php");
		exit;
	}

	add_nav("Admin", "admin.php");
	add_nav("User Admin", "admin_users.php");
	add_nav("Edit User", "admin_user.php?id=$id");

	include("head.txt");
?>

<div class="filebox">

<form action="admin_user.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="done" value="1">

Full Name:<br>
<input type="text" name="full_name" value="<?=htmlentities($user_row[full_name])?>" class="edit"><br>
<br>

Username:<br>
<input type="text" name="username" value="<?=htmlentities($user_row[username])?>" class="edit"><br>
<br>

Password:<br>
<input type="text" name="password" value="<?=htmlentities($user_row[password])?>" class="edit"><br>
<br>

Admin Rights:<br>
<input type="checkbox" name="admin_delete"<?if($user_row[admin_delete]){echo ' checked';}?>> Allow user to delete other people's files.<br>
<br>

<input type="submit" value="Save Changes">

</form>

<? if ($id){ ?>
<br>
<br>
<div class="deletebox">
	Click the button to delete this user:<br>
	<br>
	<form action="admin_user.php" method="post" onsubmit="return sure();">
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="delete" value="1">
	<input type="submit" value="Delete User">
	</form>
</div>



<? } ?>

</div>

<?
	include("foot.txt");
?>