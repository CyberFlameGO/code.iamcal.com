<?
	include("init.php");

	add_nav("Admin", "admin.php");
	add_nav("User Admin", "admin_users.php");

	include("head.txt");
?>

<div class="filebox">

<table cellpadding="0" cellspacing="2" border="0">
	<tr>
		<td><a href="admin_user.php"><img src="icons/user.gif" width="16" height="16" border="0"></a></td>
		<td><a href="admin_user.php">Create a new user</a></td>
	</tr>
</table>
<br>

<table border="1" cellpadding="4" cellspacing="0">
	<tr>
		<td><b>&nbsp;</b></td>
		<td><b>Username</b></td>
		<td><b>Password</b></td>
		<td><b>Full Name</b></td>
		<td><b>Edit</b></td>
	</tr>
<?
	$result = mysql_query("SELECT * FROM share_users ORDER BY full_name ASC", $db);
	while($row = mysql_fetch_array($result)){
		$admin = '';
		if ($row[admin_delete]){
			$admin = ' <i>(administrator)</i>';
		}
?>
	<tr>
		<td><img src="icons/user.gif" width="16" height="16"></td>
		<td><?=htmlentities($row[full_name])?><?=$admin?></td>
		<td><?=htmlentities($row[username])?></td>
		<td><?=htmlentities($row[password])?></td>
		<td><a href="admin_user.php?id=<?=$row[id]?>">edit</a></td>
	</tr>
<?
	}
?>
</table>

</div>

<?
	include("foot.txt");
?>