<?
	include("init.php");

	if ($id){
		$icon_row = mysql_fetch_array(mysql_query("SELECT * FROM share_icons WHERE id=$id",$db));
	}else{
		$icon_row = array();
	}

	if ($done){
		if ($id){
			mysql_query("UPDATE share_icons SET filename='$filename', extension='$extension' WHERE id=$id", $db);
		}else{
			mysql_query("INSERT INTO share_icons (filename, extension) VALUES ('$filename', '$extension')", $db);
		}
		header("Location: admin_icons.php");
		exit;
	}

	if ($delete){
		mysql_query("DELETE FROM share_icons WHERE id=$id", $db);
		header("Location: admin_icons.php");
		exit;
	}

	add_nav("Admin", "admin.php");
	add_nav("Icon Admin", "admin_icons.php");
	add_nav("Edit Icon Mapping", "admin_icon.php?id=$id");

	include("head.txt");
?>

<div class="filebox">

<form action="admin_icon.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="done" value="1">

File Name:<br>
<input type="text" name="filename" value="<?=htmlentities($icon_row[filename])?>" class="edit"><br>
(This file should be as 32x32 pixel gif, placed in the "custom_icons" folder)<br>
<br>

File Extension:<br>
<input type="text" name="extension" value="<?=htmlentities($icon_row[extension])?>" class="edit"><br>
(The file extension should <b>not</b> include the dot - ie. "zip" not ".zip")<br>
<br>

<input type="submit" value="Save Changes">

</form>

<? if ($id){ ?>
<br>
<br>
<div class="deletebox">
	Click the button to delete this icon mapping:<br>
	<br>
	<form action="admin_icon.php" method="post" onsubmit="return sure();">
	<input type="hidden" name="id" value="<?=$id?>">
	<input type="hidden" name="delete" value="1">
	<input type="submit" value="Delete Icon Mapping">
	</form>
</div>



<? } ?>

</div>

<?
	include("foot.txt");
?>