<html>
<head>
<script language="Javascript">

window.opener.location.reload(true);
window.close();

</script>
</head>
<body>

</body>
</html>
