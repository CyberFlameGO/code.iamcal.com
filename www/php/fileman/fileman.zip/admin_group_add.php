<?
	include("init.php");

	if ($done && $user_id){
		mysql_query("INSERT INTO share_group_members (group_id, user_id) VALUES ($id, $user_id)", $db);
		header("Location: admin_groups.php");
		exit;
	}

	$users_in_group = array();
	$result = mysql_query("SELECT user_id FROM share_group_members WHERE group_id=$id", $db);
	while($row = mysql_fetch_array($result)){
		$users_in_group[] = $row[user_id];
	}

	add_nav("Admin", "admin.php");
	add_nav("Group Admin", "admin_groups.php");
	add_nav("Add User To Group", "admin_group_add.php?id=$id");

	include("head.txt");
?>

<div class="filebox">

<?
	$options = array();
	$result = mysql_query("SELECT * FROM share_users ORDER BY full_name ASC", $db);
	while($row = mysql_fetch_array($result)){
		if (!in_array($row[id], $users_in_group)){
			$options[] = "<option value=\"$row[id]\">".htmlentities($row[full_name])."</option>\n";
		}
	}
	if (count($options)){
?>

<form action="admin_group_add.php" method="post">
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="done" value="1">

User:<br>
<select name="user_id">
<?=implode('', $options)?>
</select><br>
<br>

<input type="submit" value="Add User To Group">

</form>

<?
	}else{
?>

	There are no more users to add to this group!<br>
	<br>
	<a href="admin_groups.php">Click here</a> to go back.<br>

<?
	}
?>

</div>

<?
	include("foot.txt");
?>