<?
	$cfg = array();

	#################################################################################
	#
	# START OF OPTIONS
	#

	$cfg[db_host] = 'localhost';
	$cfg[db_user] = 'root';
	$cfg[db_pass] = '';
	$cfg[db_name] = 'share';

	$cfg[files_path] = 'c:/www/local/fileman/files';
	$cfg[cookie_path] = '/fileman/';

	#
	# END OF OPTIONS
	#
	#################################################################################

	$db = @mysql_pconnect($cfg[db_host], $cfg[db_user], $cfg[db_pass]);
	if (!$db) {
		echo "<b style=\"font-size: 150%;\">MySQL Connect Failed</b><br />\n";
		echo "<b>Error:</b> ".HtmlSpecialChars(mysql_error())."<br \>\n";
		echo "<hr />\n";
		die("");
	}
	mysql_select_db($cfg[db_name], $db);


	$cfg[acl_allow_all] = 0;
	$cfg[acl_deny_all] = 1;
	$cfg[nav] = array();
	$cfg[user] = array();
	$cfg[user][id] = 0;
	$cfg[user][groups] = array();
	$cfg[user_ok] = 0;
	$cfg[group_icon] = '<img src="icons/group.gif" width="16" height="16" border="0">';
	$cfg[user_icon] = '<img src="icons/user.gif" width="16" height="16" border="0">';

	function add_folder_path($folder_id){
		global $db;
		$links = array();
		for(;$folder_id>0;){
			$row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id='$folder_id'",$db));
			$folder_id = $row[parent_id];
			$links[] = array('title' => htmlentities($row[name]), 'url' => "./?folder_id=$row[id]");
		}
		$links = array_reverse($links);
		foreach($links as $link){
			add_nav($link[title], $link[url]);
		}
	}

	function get_folder_path($folder_id){
		global $db;
		for(;$folder_id>0;){
			$row = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id='$folder_id'",$db));
			$folder_id = $row[parent_id];
			$folders[] = htmlentities($row[name]);
		}
		$folders = array_reverse($folders);
		return implode(' / ', $folders);
	}

	function insert_title(){
		global $cfg;
		$last = count($cfg[nav]) - 1;
		echo $cfg[nav][$last][title];
	}

	function show_nav(){
		global $cfg;
		$final = array();
		foreach($cfg[nav] as $elm){
			$final[] = "<a href=\"$elm[url]\">$elm[title]</a>";
		}
		$null = array_pop($final);
		$last = count($cfg[nav]) - 1;
		$final[] = $cfg[nav][$last][title];
		echo implode(' / ', $final);
	}

	function add_nav($title, $url){
		global $cfg;
		$cfg[nav][] = array('title' => $title, 'url' => $url);
	}

	function create_new_acl($mode){
		global $db, $cfg;
		mysql_query("INSERT INTO share_acls (mode) VALUES ($mode)", $db);
		return mysql_insert_id();
	}

	function create_folder($name, $parent){
		global $db, $cfg;
		$read_acl = create_new_acl($cfg[acl_allow_all]);
		$write_acl = create_new_acl($cfg[acl_deny_all]);
		mysql_query("INSERT INTO share_folders (parent_id, name, write_acl_id, read_acl_id) VALUES ('$parent', '$name', $write_acl, $read_acl)", $db);
		return mysql_insert_id();
	}

	function get_child_folders($folder){
		global $db;
		$out = array($folder);
		$result = mysql_query("SELECT * FROM share_folders WHERE parent_id=$folder", $db);		
		while($row = mysql_fetch_array($result)){
			$out = array_merge($out, get_child_folders($row[id]));
		}
		return $out;
	}

	function get_acl($id){
		global $db;
		$out = mysql_fetch_array(mysql_query("SELECT * FROM share_acls WHERE id=$id",$db));
		$out[groups] = array();
		$out[users] = array();
		$result = mysql_query("SELECT * FROM share_acl_perms WHERE acl_id=$id",$db);
		while($row = mysql_fetch_array($result)){
			if ($row[group_id]){
				$out[groups][] = $row[group_id];
			}else{
				$out[users][] = $row[user_id];
			}
		}
		return $out;
	}

	function show_acl($id){
		global $db, $cfg;

		echo '<table border="0" cellpadding="4" cellspacing="0">';

		$acl = get_acl($id);
		$except = (count($acl[users]) || count($acl[groups]))?'except:':'';
		if ($acl[mode] == $cfg[acl_allow_all]){
			echo "<tr><td colspan=\"2\">Allow all $except</td></tr>\n";
		}else{
			echo "<tr><td colspan=\"2\">Deny all $except</td></tr>\n";
		}
		foreach($acl[groups] as $group){
			list($name) = mysql_fetch_array(mysql_query("SELECT name FROM share_groups WHERE id=$group", $db));
			echo "<tr>\n";
			echo "<td>$cfg[group_icon]</td>\n";
			echo "<td><i>$name</i></td>\n";
			echo "</tr>\n";
		}
		foreach($acl[users] as $user){
			list($name) = mysql_fetch_array(mysql_query("SELECT full_name FROM share_users WHERE id=$user", $db));
			echo "<tr>\n";
			echo "<td>$cfg[user_icon]</td>\n";
			echo "<td><i>$name</i></td>\n";
			echo "</tr>\n";
		}

		echo '</table>';
	}


	function insert_acl_editor($link, $id){
		global $db, $cfg;

		$acl = get_acl($id);
		$except = (count($acl[users]) || count($acl[groups]))?'except:':'';
		if ($acl[mode] == $cfg[acl_allow_all]){
			echo "<tr><td colspan=\"2\">Allow all $except (<a href=\"$link&acl_mode=$id&value=$cfg[acl_deny_all]\">Toggle mode</a>)</td></tr>\n";
		}else{
			echo "<tr><td colspan=\"2\">Deny all $except (<a href=\"$link&acl_mode=$id&value=$cfg[acl_allow_all]\">Toggle mode</a>)</td></tr>\n";
		}
		foreach($acl[groups] as $group){
			list($name) = mysql_fetch_array(mysql_query("SELECT name FROM share_groups WHERE id=$group", $db));
			echo "<tr>\n";
			echo "<td>$cfg[group_icon]</td>\n";
			echo "<td><i>$name</i> - <a href=\"$link&remove_group=$group&acl=$id\">Remove</a></td>\n";
			echo "</tr>\n";
		}
		foreach($acl[users] as $user){
			list($name) = mysql_fetch_array(mysql_query("SELECT full_name FROM share_users WHERE id=$user", $db));
			echo "<tr>\n";
			echo "<td>$cfg[user_icon]</td>\n";
			echo "<td><i>$name</i> - <a href=\"$link&remove_user=$user&acl=$id\">Remove</a></td>\n";
			echo "</tr>\n";
		}
	}

	function delete_folder($id){
		global $db;
		$folder = mysql_fetch_array(mysql_query("SELECT * FROM share_folders WHERE id=$id",$db));
		delete_acl($folder[read_acl_id]);
		delete_acl($folder[write_acl_id]);
		mysql_query("DELETE FROM share_folders WHERE id=$id", $db);
	}

	function delete_acl($id){
		global $db;
		mysql_query("DELETE FROM share_acl_perms WHERE acl_id=$id", $db);
		mysql_query("DELETE FROM share_acls WHERE id=$id", $db);
	}

	function delete_user($id){
		global $db;
		mysql_query("DELETE FROM share_acl_perms WHERE user_id=$id", $db);
		mysql_query("DELETE FROM share_group_members WHERE user_id=$id", $db);
		mysql_query("DELETE FROM share_users WHERE id=$id", $db);
		mysql_query("UPDATE share_files SET user_id=0 WHERE user_id=$id", $db);
	}

	function delete_group($id){
		global $db;
		mysql_query("DELETE FROM share_acl_perms WHERE group_id=$id", $db);
		mysql_query("DELETE FROM share_group_members WHERE group_id=$id", $db);
		mysql_query("DELETE FROM share_groups WHERE id=$id", $db);
	}

	function get_user($id){
		global $db;
		$out = mysql_fetch_array(mysql_query("SELECT * FROM share_users WHERE id=$id", $db));
		$out[groups] = array();
		$result = mysql_query("SELECT * FROM share_group_members WHERE user_id=$id",$db);
		while($row = mysql_fetch_array($result)){
			$out[groups][] = $row[group_id];
		}
		return $out;
	}

	function check_login(){
		global $cfg, $db, $HTTP_COOKIE_VARS;
		if ($temp = mysql_fetch_array(mysql_query("SELECT * FROM share_users WHERE username LIKE '$HTTP_COOKIE_VARS[fileman_username_cookie]' AND password LIKE '$HTTP_COOKIE_VARS[fileman_password_cookie]'", $db))){
			$cfg[user_ok] = 1;
			$cfg[user] = get_user($temp[id]);
		}
	}

	function show_login(){
		global $cfg;
		if ($cfg[user_ok]){
			echo "Logged in as {$cfg[user][full_name]} [<a href=\"logout.php\">log out</a>]";
		}else{
			$last = count($cfg[nav]) - 1;
			$redir = urlencode($cfg[nav][$last][url]);
			if ($cfg[nav][$last][url] == 'login.php'){ $redir = ''; }
			echo "You are not logged in [<a href=\"login.php?redir=$redir\">log in</a>]";
		}
	}

	function check_permission($user, $acl_id){
		global $cfg;

		$acl = get_acl($acl_id);

		if (!$user[id]){
			# user not logged in
			if (($acl[mode] == $cfg[acl_allow_all]) && (!count($acl[groups])) && (!count($acl[users]))){
				return 1;
			}
			return 0;
		}

		$clash = 0;
		if (in_array($user[id], $acl[users])){
			$clash = 1;
		}
		foreach($user[groups] as $group){
			if (in_array($group, $acl[groups])){
				$clash = 1;
			}
		}
		if ($acl[mode] == $cfg[acl_allow_all]){
			return !$clash;
		}else{
			return $clash;
		}
	}

	function upload_file($field){
		global $cfg, $HTTP_POST_FILES;

		$path = $cfg[files_path];

		if ($HTTP_POST_FILES[$field]['name'] != ""){
			$src = $HTTP_POST_FILES[$field]['tmp_name'];
			$dest = trim($HTTP_POST_FILES[$field]['name']);
			$i=0;
			while(file_exists("$path/$dest")){
				$dest = $i.'_'.trim($HTTP_POST_FILES[$field]['name']);
				$i++;
			}
			copy($src,"$path/$dest");
			chmod("$path/$dest", 0777);
			return $dest;
		}
		return 0;
	}

	function load_icon_mappings(){
		global $db;
		$out = array();
		$result = mysql_query("SELECT * FROM share_icons", $db);
		while($row = mysql_fetch_array($result)){
			$out[$row[extension]] = "custom_icons/$row[filename]";
		}
		return $out;
	}

	function get_extension($filename){
		$bits = explode('.', $filename);
		return array_pop($bits);
	}

	function get_filesize($filename){
		global $cfg;
		$bytes = filesize("$cfg[files_path]/$filename");
		if ($bytes > (1024 * 1024)){
			return round_size($bytes / (1024 * 1024))." MB";
		}
		if ($bytes > 1024){
			return round_size($bytes / 1024)." KB";
		}
		return $bytes." bytes";
	}

	function round_size($a){
		return floor($a*10)/10;
	}

	function delete_file($id){
		global $db, $cfg;
		$file_row = mysql_fetch_array(mysql_query("SELECT * FROM share_files WHERE id=$id"));
		mysql_query("DELETE FROM share_files WHERE id=$id", $db);
		unlink("$cfg[files_path]/$file_row[filename_on_disk]");
	}
	
	add_nav("Home", "./");
	check_login();
?>