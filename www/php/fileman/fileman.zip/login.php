<?
	include("init.php");

	if ($done){
		if ($temp = mysql_fetch_array(mysql_query("SELECT * FROM share_users WHERE username LIKE '$username' AND password LIKE '$password'", $db))){
			setcookie("fileman_username_cookie", $username, 0, $cfg[cookie_path]);
			setcookie("fileman_password_cookie", $password, 0, $cfg[cookie_path]);
			if ($redir){
				header("Location: $redir");
			}else{
				header("Location: ./");
			}
			exit;
		}
	}

	add_nav("Log In", "login.php");
	include("head.txt");
?>

<div class="filebox">

<form action="login.php" method="post">
<input type="hidden" name="done" value="1">
<input type="hidden" name="redir" value="<?=htmlentities($redir)?>">

<? if ($done){ ?>
<div class="deletebox">
	The username and password you entered were not valid.
</div>
<br>
<? } ?>

Username:<br>
<input type="text" name="username"><br>
<br>

Password:<br>
<input type="password" name="password"><br>
<br>

<input type="submit" value="Log In">

</form>

</div>

<?
	include("foot.txt");
?>