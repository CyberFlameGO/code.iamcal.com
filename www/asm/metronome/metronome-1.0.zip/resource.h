//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by metronome.rc
//
#define IDR_MAIN                        101
#define IDD_DIALOG1                     102
#define IDC_EDIT1                       1000
#define ID_EXIT                         40002
#define ID_OPEN                         40003
#define ID_SETTIME                      40003
#define ID_RUNNING                      40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
