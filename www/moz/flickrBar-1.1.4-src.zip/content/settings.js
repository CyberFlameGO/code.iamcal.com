
window.addEventListener("load", onWindowLoad, false); 


function onWindowLoad(e){

	var pwin = document.getElementById('FlickrBarPrefs');
	var pane = document.getElementById('paneOne');

	pwin.showPane(pane);

	document.getElementById('privacyGroup').addEventListener('RadioStateChange', onPrivacyStateChange, false);
	document.getElementById('privacyGroup').selectedIndex = document.getElementById('pref-is_public').value ? 1 : 0;
	onPrivacyStateChange();
}

function onPrivacyStateChange(e){

	var public = document.getElementById('publicRadio').selected;

	document.getElementById('friendsCheck').disabled = public;
	document.getElementById('familyCheck').disabled = public;
	document.getElementById('pref-is_public').value = public;
}
