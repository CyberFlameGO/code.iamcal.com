window.addEventListener("load", onWindowLoad, false); 

var item = null;

function onWindowLoad(e){

	document.getElementById('privacyGroup').addEventListener('RadioStateChange', onPrivacyStateChange, false);
	document.getElementById('privacyGroup').selectedIndex = 1;
	onPrivacyStateChange();

	// set dialog prefs from item?

	item = window.arguments[0];

	if (!item) return;

	document.getElementById('privacyGroup').selectedIndex = item.is_public ? 1 : 0;
	document.getElementById('friendsCheck').checked = item.is_friend;
	document.getElementById('familyCheck').checked = item.is_family;
	onPrivacyStateChange();

	document.getElementById('editTitle').value = item.title;
	document.getElementById('editDescription').value = item.description;
	document.getElementById('editTags').value = item.tags;

	var img = new Image();
	img.src = item.url;
	img.onload = function(){
		var w = img.width;
		var h = img.height;

		var image = document.getElementById('previewImage');

		var dw = parseInt(document.defaultView.getComputedStyle(image, null).getPropertyValue("width"));
		var dh = parseInt(document.defaultView.getComputedStyle(image, null).getPropertyValue("height"));

		var s_ratio = w/h;
		var d_ratio = dw/dh;

		var th = 0;
		var tw = 0;

		if (dw > w && dh > h){

			tw = w;
			th = h;

		}else{

			if (s_ratio > d_ratio){

				tw = dw;
				th = dh / s_ratio;
			}else{

				th = dh;
				tw = dw * s_ratio;
			}
		}

		var tx = Math.round((dw - tw) / 2);
		var ty = Math.round((dh - th) / 2);

		var ctx = image.getContext('2d');
		ctx.drawImage(img, 0, 0, w, h, tx, ty, tw, th);

		delete img;
	};
}

function onPrivacyStateChange(e){

	var private = document.getElementById('privateRadio').selected;

	document.getElementById('friendsCheck').disabled = !private;
	document.getElementById('familyCheck').disabled = !private;
}

function onAccept(){

	item.title = document.getElementById('editTitle').value;
	item.description = document.getElementById('editDescription').value;
	item.tags = document.getElementById('editTags').value;

	item.is_public = (document.getElementById('privacyGroup').selectedIndex == 1) ? 1 : 0;
	item.is_friend = document.getElementById('friendsCheck').checked;
	item.is_family = document.getElementById('familyCheck').checked;
}

function resizeImage(){
	var image = document.getElementById('previewImage');

}