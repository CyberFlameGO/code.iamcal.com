var dragTarget = null;
var draggingNow = null;

var flickrBarflavors = new FlavourSet();
flickrBarflavors.appendFlavour("application/x-moz-file","nsIFile");

dropObserver = {

	canHandleMultipleItems: true,
	onDragOver: function(event, dragData){

		dragOver(event.clientX, event.clientY);
	},
	onDrop:	function(event, dropData){

		dropEnd();

		dropData.dataList.forEach(function(value){

			if (value.first.data.isDirectory()){

				var files = value.first.data.directoryEntries;

				while (files.hasMoreElements()){

					var file = files.getNext().QueryInterface(Components.interfaces.nsIFile);

					insertFileIntoUploadQueue(file);
				}
			}else{
				var file = value.first.data.QueryInterface(Components.interfaces.nsIFile);

				insertFileIntoUploadQueue(file);
			}
		});

		if (!flickrBarShowing()){
			showBar();
		}
	},
	onDragEnter: function(event, flavour, session){

	},
	onDragExit: function(event, flavour, session){

		// this *might* be the real end of a drag session.
		// however, we might get another onEnter and onDragOver
		// in just a moment. we delay stopping the drag for 200ms
		// to allow time for the next event to fire and continue
		// the drag.

		startDropEnd();
	},
	getSupportedFlavours: function(){

		return flickrBarflavors;
	}
};


function dragOver(x, y){
	endDropEnd();

	if (!draggingNow){
		startADrag(dragTarget);
	}else{
		if (draggingNow != dragTarget){
			stopADrag(draggingNow);
			startADrag(dragTarget);
		}
	}
	draggingNow = dragTarget;

	if (draggingNow == 'queue'){

		var cursor = document.getElementById('dragCursor');

		x -= document.getElementById('flickrBar').boxObject.x;
		y -= document.getElementById('flickrBar').boxObject.y;

		cursor.style.left = x+'px';
		cursor.style.top = y+'px';
	}
}

function startADrag(target){

	if (target == 'queue'){

		//var cursor = document.getElementById('dragCursor');

		//cursor.style.left = '-1000px';
		//cursor.style.display = 'block';
	}

	if (target == 'nav'){
		document.getElementById('navBarBody').className = 'navBarDropHover';
	}
}

function stopADrag(target){

	if (target == 'queue'){

		//var cursor = document.getElementById('dragCursor');

		//cursor.style.display = 'none';
	}

	if (target == 'nav'){
		document.getElementById('navBarBody').className = '';
	}
}

var dropEndTimer = null;

function startDropEnd(){
	dropEndTimer = window.setTimeout('dropEnd()', 200);
}

function endDropEnd(){
	if (dropEndTimer != null){
		window.clearTimeout(dropEndTimer);
		dropEndTimer = null;
	}
}

function dropEnd(){
	dropEndTimer = null;
	stopADrag(draggingNow);
	draggingNow = null;
}