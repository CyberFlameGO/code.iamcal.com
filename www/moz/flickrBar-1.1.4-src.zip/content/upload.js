
var header_boundary = '---------------------------' + new Date().getTime();
var multipart_boundary = '--' + header_boundary;

function uploadFileToFlickr(item){

	waiting_for_upload = 1;

	var nsIFileInputStream = Components.classes["@mozilla.org/network/file-input-stream;1"].createInstance(Components.interfaces.nsIFileInputStream);
	nsIFileInputStream.init(item.file, 1, 1, Components.interfaces.nsIFileInputStream.CLOSE_ON_EOF);

	var nsIBufferedInputStream = Components.classes["@mozilla.org/network/buffered-input-stream;1"].createInstance(Components.interfaces.nsIBufferedInputStream);
	nsIBufferedInputStream.init(nsIFileInputStream, 4096);

	var nsIStringInputStream_start = Components.classes["@mozilla.org/io/string-input-stream;1"].createInstance(Components.interfaces.nsIStringInputStream);
	nsIStringInputStream_start.setData(getStreamData(item), -1);

	var nsIStringInputStream_end = Components.classes["@mozilla.org/io/string-input-stream;1"].createInstance(Components.interfaces.nsIStringInputStream);
	nsIStringInputStream_end.setData("\r\n" + multipart_boundary + "--\r\n", -1);

	var nsIMultiplexInputStream = Components.classes["@mozilla.org/io/multiplex-input-stream;1"].createInstance(Components.interfaces.nsIMultiplexInputStream);
	nsIMultiplexInputStream.appendStream(nsIStringInputStream_start);
	nsIMultiplexInputStream.appendStream(nsIBufferedInputStream);
	nsIMultiplexInputStream.appendStream(nsIStringInputStream_end);

	var req = new XMLHttpRequest();
	item.req = req;
	item.totalSize = nsIMultiplexInputStream.available();

	req.onerror = {
		item: item,
		handleEvent: requestOnError
	};

	req.onload = {
		item: item,
		handleEvent: requestOnLoad
	};

	req.onreadystatechange = function() {
		
	};

	req.open("POST", 'http://www.flickr.com/services/upload/', true);
	req.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + header_boundary);

	req.send(nsIMultiplexInputStream);

	req.progressTimer = window.setInterval(function(){ itemProgress(item, nsIMultiplexInputStream); }, 200);

	return req;
}

function itemProgress(item, stream){

	var avail = stream.available();
	var percent = 100 - Math.round(100 * avail / item.totalSize);

	if (avail == 0){
		stopUploadProgressTimer(item);
	}

	//debug(percent+'% done');
	updateUploadProgress(item, percent);
}

function stopUploadProgressTimer(item){
	window.clearInterval(item.progressTimer);
}

function getStreamData(item){

	var out = "\r\n" + multipart_boundary;

	var token = flickrGetCharPref("auth_token");

	var params = {};
	params.title = item.title;
	params.is_public = item.is_public;
	params.is_friend = item.is_friend;
	params.is_family = item.is_family;
	params.description = item.description;
	params.tags = item.tags;
	params.auth_token = token;
	params.async = 1;
	params = generate_sig(params);


	for (p in params){
		out += "\r\nContent-Disposition: form-data; name=\""+p+"\"\r\n\r\n"+params[p]+"\r\n" + multipart_boundary;
	}

	out += "\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"" + item.label + "\"\r\nContent-Type: image/jpeg\r\n\r\n";

	return out;
}

function requestOnError(event){

	stopUploadProgressTimer(this.item);

	waiting_for_upload = 0;

	alert('fail on '+this.item.label);
}

function requestOnLoad(event){

	stopUploadProgressTimer(this.item);

	waiting_for_upload = 0;

	var ticket_elm = event.target.responseXML.documentElement.getElementsByTagName('ticketid')[0];

	if (ticket_elm){
		var ticket = ticket_elm.childNodes[0].nodeValue;

		gotTicketForItem(this.item, ticket);
		return;
	}

	alert("Something went wrong. Response was "+event.target.responseText);
}
