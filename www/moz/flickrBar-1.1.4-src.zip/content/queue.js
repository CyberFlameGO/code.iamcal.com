var scrollDir = 1;
var scrollTimer = null;
var state_counts = {
		'queued': 0,
		'sending': 0,
		'waiting': 0,
		'done': 0
	};

window.addEventListener("load", onQueueLoad, false); 

function onQueueLoad(){
	updateScrollButtonStates();
}

function down(elm){

	if (elm.className == 'buttonDisabled') return;

	elm.className = 'buttonDown';
	scrollDir = (elm.id == 'leftArrow') ? -1 : 1;
	scrollTimer = window.setInterval(scrollMe, 100);
	scrollMe();
}

function up(elm){
	if (elm.className == 'buttonDisabled') return;

	elm.className = '';

	stopQueueScroll();
}

function stopQueueScroll(){

	if (scrollTimer){
		window.clearInterval(scrollTimer);
		scrollTimer = null;
	}
}

function scrollMe(){
	document.getElementById('imageTray').boxObject.QueryInterface(Components.interfaces.nsIScrollBoxObject).scrollBy(30 * scrollDir, 0);

	updateScrollButtonStates();
}


function createListItem(item){

	createImageLayers(item);
	changedState(item);

	if (item.thumb){
		updateThumb(item);
	}

	updateScrollButtonStates();
}

function destroyListItem(item){

	var root = document.getElementById('imageBorder'+item.id);

	root.parentNode.removeChild(root);

	updateScrollButtonStates();

	if (!upload_queue.length){
		document.getElementById('dropme').style.display = 'block';
	}
}

function changedState(item){

	document.getElementById('imageProgressFrame'+item.id).style.display	= (item.state == 'sending') ? 'block' : 'none';
	document.getElementById('imageWaitFrame'+item.id).style.display		= (item.state == 'waiting') ? 'block' : 'none';
	document.getElementById('imageQueueFrame'+item.id).style.display	= 'none';
	document.getElementById('imageDoneFrame'+item.id).style.display		= 'none';
}

function createImageLayers(item){

	var id = item.id;
	var src_url = item.url;
	var label = item.label;
	var html = 'http://www.w3.org/1999/xhtml';

	document.getElementById('dropme').style.display = 'none';

	var bdr = document.createElement('DIV');
	bdr.className = 'imageBorder';
	bdr.id = 'imageBorder'+id;

	var frm = document.createElementNS(html, 'html:div');
	frm.className = 'imageFrame';
	frm.id = 'imageFrame'+id;


	//
	// create thumbnail canvas
	//

	var prv = document.createElementNS(html, 'html:canvas');
	prv.id = 'imagePreview'+id;
	prv.className = 'imagePreview';
	prv.width = thumb_width;
	prv.height = thumb_height;


	//
	// progress bar
	//

	var pgf = document.createElement('DIV');
	pgf.className = 'imageProgressFrame';
	pgf.id = 'imageProgressFrame'+id;

	var pgb = document.createElement('DIV');
	pgb.className = 'imageProgressBar';
	pgb.id = 'imageProgressBar'+id;

	var pgl = document.createElement('DIV');
	pgl.className = 'imageProgressLabel';
	pgl.id = 'imageProgressLabel'+id;

	pgl.appendChild(document.createTextNode('Uploading'));

	pgf.appendChild(pgb);
	pgf.appendChild(pgl);


	//
	// wait bar
	//

	var wtf = document.createElement('DIV');
	wtf.className = 'imageProgressFrame';
	wtf.id = 'imageWaitFrame'+id;

	var wtb = document.createElement('DIV');
	wtb.className = 'imageWaitBar';

	var wtl = document.createElement('DIV');
	wtl.className = 'imageProgressLabel';

	wtl.appendChild(document.createTextNode('Verifying'));

	wtf.appendChild(wtb);
	wtf.appendChild(wtl);


	//
	// queue bar
	//

	var quf = document.createElement('DIV');
	quf.className = 'imageQueueFrame';
	quf.id = 'imageQueueFrame'+id;

	var qul = document.createElement('DIV');
	qul.className = 'imageQueueLabel';

	qul.appendChild(document.createTextNode('Queued'));

	quf.appendChild(qul);


	//
	// done bar
	//

	var dof = document.createElement('DIV');
	dof.className = 'imageQueueFrame';
	dof.id = 'imageDoneFrame'+id;

	var dol = document.createElement('DIV');
	dol.className = 'imageQueueLabel';

	dol.appendChild(document.createTextNode('Uploaded'));

	dof.appendChild(dol);


	//
	// cover
	//

	var cvr = document.createElementNS(html, 'html:div');
	cvr.className = 'imageCover';
	cvr.onmouseover = function(){ var aitem = item; thumbHover(item); }
	cvr.onmouseout = function(){ var aitem = item; thumbUnhover(item); }

	var cvr_lnk = document.createElementNS(html, 'html:a');
	cvr_lnk.href = '#';
	cvr_lnk.onclick = function(e){

		var aitem = item;
		clickQueueItem(aitem, e.layerX, e.layerY);
		return false;
	};
	cvr_lnk.appendChild(cvr);


	//
	// close button
	//

	var clb = document.createElementNS(html, 'html:div');
	clb.className = 'imageCloseButton';
	clb.id = 'imageCloseButton'+id;


	//
	// put it all together
	//

	frm.appendChild(prv);
	frm.appendChild(pgf);
	frm.appendChild(wtf);
	frm.appendChild(quf);
	frm.appendChild(dof);
	frm.appendChild(clb);
	frm.appendChild(cvr_lnk);

	bdr.appendChild(frm);

	document.getElementById('imageTray').appendChild(bdr);
}

function updateThumb(item){
	var canvas = document.getElementById('imagePreview'+item.id);
	if (canvas){

		canvas.getContext('2d').drawImage(item.thumb, 0, 0);
	}
}

function findQueuedItem(id){
	for (var i=0; i<item_queue.length; i++){
		var item = item_queue[i];
		if (item.id == id){

			return item;
		}
	}

	return null;
}

function thumbHover(item){

	if (item.state == 'queued'){
		document.getElementById('imageQueueFrame'+item.id).style.display = 'block';
	}
	if (item.state == 'done'){
		document.getElementById('imageDoneFrame'+item.id).style.display = 'block';
	}

	document.getElementById('imageCloseButton'+item.id).style.display = 'block';
}

function thumbUnhover(item){
	document.getElementById('imageQueueFrame'+item.id).style.display = 'none';
	document.getElementById('imageDoneFrame'+item.id).style.display = 'none';
	document.getElementById('imageCloseButton'+item.id).style.display = 'none';
}

function updateItemProgress(item, percent){

	var bar = document.getElementById('imageProgressBar'+item.id);

	if (bar){
		bar.style.width = Math.round(64 * percent / 100) + 'px';
	}
}

function updateScrollButtonStates(){

	var tray = document.getElementById('imageTray');
	var anon = document.getAnonymousNodes(tray)[0];

	var content_w = anon.boxObject.width;
	var tray_w = tray.boxObject.width;

	var x = {value: 0};
	var y = {value: 0};

	try{
		tray.boxObject.QueryInterface(Components.interfaces.nsIScrollBoxObject).getPosition(x, y);;
	}catch(e){}

	var enable_l = (x.value > 0) ? 1 : 0;
	var enable_r = (content_w - x.value > tray_w) ? 1 : 0;

	var l_elm = document.getElementById('leftArrow');
	var r_elm = document.getElementById('rightArrow');

	if (enable_l && l_elm.className == 'buttonDisabled'){ l_elm.className = ''; }
	if (enable_r && r_elm.className == 'buttonDisabled'){ r_elm.className = ''; }

	if (!enable_l && l_elm.className != 'buttonDisabled'){ l_elm.className = 'buttonDisabled'; stopQueueScroll(); }
	if (!enable_r && r_elm.className != 'buttonDisabled'){ r_elm.className = 'buttonDisabled'; stopQueueScroll(); }
}

function changeItemState(item, new_state){

	if (item.state){
		state_counts[item.state]--;
	}

	if (new_state){
		state_counts[new_state]++;

		item.state = new_state;

		changedState(item);
	}

	updateMiddleNav();
}
