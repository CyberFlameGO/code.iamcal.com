var thumb_width = 72;
var thumb_height = 72;
var thumb_queue = [];
var doing_thumb = 0;

function createThumbnail(item){

	thumb_queue.push(item);

	drainThumbQueue(0);
}

function drainThumbQueue(reset){

	if (reset) doing_thumb = 0;

	if (!thumb_queue.length) return;

	if (doing_thumb) return;

	doing_thumb = 1;

	doCreateThumbmnail(thumb_queue.shift());
}

function doCreateThumbmnail(item){

	var canvas = document.createElementNS('http://www.w3.org/1999/xhtml', 'html:canvas');
	canvas.width = thumb_width;
	canvas.height = thumb_height;

	var ctx = canvas.getContext('2d');
	var img = new Image();
	img.src = item.url;
	img.onload = function(){

		var w = img.width;
		var h = img.height;

		var sz = Math.min(w, h);

		if (w > h){
			sx = Math.round((w-h)/2);
			sy = 0;
		}else{
			sx = 0;
			sy = Math.round((h-w)/2);
		}

		ctx.drawImage(img, sx, sy, sz, sz, 0, 0, thumb_width, thumb_height);

		delete img;

		item.thumb = canvas;

		updateThumb(item);

		drainThumbQueue(1);
	}
}
