
function debug_obj(x){
	var buffer = '<table border="1">';
	for (i in x){
		var s = '[Exception]';
		try {
			s = ''+x[i];
		}catch(e){
		}

		var s_out = escape_html(s);
		var i_out = escape_html(i);

		if (!s_out.length) s_out = '&nbsp;';

		buffer += "<tr valign=\"top\"><td><pre>"+i_out+"</pre></td><td><pre>"+s_out+"</pre></td></tr>\n";
	}

	buffer += "</table>";

	debug(buffer);
}

function escape_html(s){
	return s.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;');
}

function debug(str){

	var debug_url = "about:blank";

	var appcontent = document.getElementById("appcontent");
	if (appcontent){
		var closure = function(aEvent){

			var doc = aEvent.originalTarget;
			if (doc.location.href == debug_url){

				appcontent.removeEventListener("load", closure, true);

				doc.documentElement.innerHTML += str;

				doc.title = 'Debug';
			}

		};

		appcontent.addEventListener("load", closure, true);
	}

	tab = gBrowser.addTab(debug_url);
	gBrowser.selectedTab = tab;
}

function myDump(aMessage) {
	var consoleService = Components.classes["@mozilla.org/consoleservice;1"].getService(Components.interfaces.nsIConsoleService);
	consoleService.logStringMessage("[DEBUG] " + aMessage);
}
