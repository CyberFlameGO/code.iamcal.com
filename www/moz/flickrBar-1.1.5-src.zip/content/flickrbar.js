var bar_showing = 0;
var upload_queue = [];
var login_status = 'checking';
var upload_file_count = 0;
var waiting_for_upload = 0;
var queue_runner_paused = 0;
var queue_is_waiting = 0;
var upload_once_loggged_in = 0;

function flickrBarShowing(){
	return bar_showing;
}

function toggleFlickrBar(){

	if (flickrBarShowing()){

		hideBar();
	}else{
		showBar();
	}
}

function showBar(){
	document.getElementById('flickrBar').style.display = '-moz-box';
	document.getElementById('flickrBarSpacer').style.display = '-moz-box';

	//document.getElementById('flickrBarStatusIcon').src = 'chrome://flickrbar/skin/icon_16.png';

	bar_showing = 1;
}

function hideBar(){
	document.getElementById('flickrBar').style.display = 'none';
	document.getElementById('flickrBarSpacer').style.display = 'none';

	//document.getElementById('flickrBarStatusIcon').src = 'chrome://flickrbar/skin/icon_16_off.png';

	bar_showing = 0;
}

var flickrBarPrefObserver = {

	register: function(){

		this._branch = flickrBarGetPrefs();
		this._branch.QueryInterface(Components.interfaces.nsIPrefBranch2);
		this._branch.addObserver("", this, false);
	},

	unregister: function(){

		if (!this._branch) return;
		this._branch.removeObserver("", this);
	},

	observe: function(aSubject, aTopic, aData){

		if (aTopic != "nsPref:changed") return;

		switch (aData) {
			case "show_bar":
				break;
			case "bar_size":
				break;
		}
	}
}

function flickrBarOnLoad(){

	flickrBarPrefObserver.register();

	checkLoginOnStartup();
}

function onunload(){

	flickrBarPrefObserver.unregister();
}

window.addEventListener("load", function(e) { flickrBarOnLoad(e); }, false); 


function startLoginProcess(){

	var frob = api_get_frob();

	if (frob == null){
		alert("We couldn't start the Flickr login process.\n\nThis probably means you're not connected to the Internet.");
		return;
	}

	flickrSetCharPref("auth_frob", frob);

	var url = bake_login_url({'frob' : frob, 'perms' : 'delete'});

	startWatchingForPageLoads();

	openUILinkIn(url, 'tab');
}

function startWatchingForPageLoads(){

	var appcontent = document.getElementById("appcontent");
	if (appcontent) appcontent.addEventListener("load", onLoadPageInTab, true);
}

function stopWatchingForPageLoads(){

	var appcontent = document.getElementById("appcontent");
	if (appcontent) appcontent.removeEventListener("load", onLoadPageInTab, true);
}

function onLoadPageInTab(aEvent){

	var doc = aEvent.originalTarget;

	if (doc.location.href.search('flickr.com/services/auth/') > -1){

		var ps = doc.getElementsByTagName('p');

		for (var i=0; i<ps.length; i++){
			var p = ps[i];
			var inner = p.innerHTML;
			if (inner.search('You have successfully authorized the application') > -1){

				continueAuthProcess();
				return;
			}
		}
	}
}

function continueAuthProcess(){

	stopWatchingForPageLoads();

	var frob = flickrGetCharPref("auth_frob");

	var token = api_get_token(frob);

	if (!token.token){
		alert("Failed to exchange frob for token :(");
		return;
	}

	flickrClearUserPref("auth_frob");
	flickrSetCharPref("auth_token", token.token);
	flickrSetCharPref("auth_nsid", token.user_id);
	flickrSetCharPref("auth_name", token.user_name);

	updateLoginStatus('logged_in');

	if (upload_once_loggged_in){

		upload_once_loggged_in = 0;

		drainQueue();
	}
}

function insertFileIntoUploadQueue(file){

	var item = {};
	item.id = ++upload_file_count;
	item.file = file;
	item.path = file.path;
	item.url = 'file://'+file.path;
	item.label = file.leafName;
	item.state = null;
	item.title = file.leafName;
	item.description = '';
	item.is_public = flickrGetBoolPref("is_public") ? 1 : 0;
	item.is_friend = flickrGetBoolPref("is_friend") ? 1 : 0;
	item.is_family = flickrGetBoolPref("is_family") ? 1 : 0;
	item.tags = '';

	createThumbnail(item);

	upload_queue.push(item);

	createListItem(item);

	changeItemState(item, 'queued');

	if (flickrGetBoolPref('auto_upload')){
		drainQueue();
	}
}

function updateUploadProgress(item, percent){

	updateItemProgress(item, percent);
}

function showFlickr(){
	openUILinkIn('http://www.flickr.com/', 'tab');
}

function logOut(){

	flickrClearUserPref("auth_token");
	flickrClearUserPref("auth_nsid");
	flickrClearUserPref("auth_name");

	openUILinkIn('http://www.flickr.com/logout.gne', 'tab');

	updateLoginStatus('logged_out');
}

function fetchQueue(){
	return upload_queue;
}

function getLoginStatus(){

	var name = flickrGetCharPref("auth_name");

	return [login_status, name];
}

function checkLoginOnStartup(){

	var token = flickrGetCharPref("auth_token");

	if (token){

		updateLoginStatus('checking');

		var listener = {
			'flickr_auth_checkToken_onLoad': function (success, responseXML, responseText, params){

				if (success && responseXML){
					var token_elm = responseXML.documentElement.getElementsByTagName('token')[0];
					var user_elm = responseXML.documentElement.getElementsByTagName('user')[0];

					flickrSetCharPref("auth_token", token_elm.childNodes[0].nodeValue);
					flickrSetCharPref("auth_nsid", user_elm.getAttribute('nsid'));
					flickrSetCharPref("auth_name", user_elm.getAttribute('username'));

					updateLoginStatus('logged_in');
				}else{
					logOut();
				}
			}
		};
		flickrAPI.callMethod('flickr.auth.checkToken', { 'auth_token': token }, listener, 2, 0);
	}else{
		updateLoginStatus('logged_out');
	}
}

function updateLoginStatus(status){

	login_status = status;

	navBarUpdateLoginStatus();

	drainQueue();
}

function findNextInQueue(){

	for (var i=0; i<upload_queue.length; i++){

		var item = upload_queue[i];

		if (item.state == 'queued'){

			return item;
		}
	}

	return null;
}

function drainQueue(){

	if (login_status != 'logged_in'){ return; }
	if (waiting_for_upload){ return; }

	if (queue_runner_paused){
		queue_is_waiting = 1;
		return;
	}

	queue_is_waiting = 0;

	var item = findNextInQueue();

	if (!item){ return; }

	changeItemState(item, 'sending');

	uploadFileToFlickr(item);
}

function gotTicketForItem(item, ticket){

	item.ticket = ticket;

	changeItemState(item, 'waiting');

	api_wait_for_ticket(ticket);

	drainQueue();
}

function gotPhotoIdForTicket(ticket, photoid){

	for (var i=0; i<upload_queue.length; i++){

		var item = upload_queue[i];

		if (item.ticket == ticket){

			item.photoid = photoid;

			if (flickrGetBoolPref('auto_clear')){

				removeItem(item);
			}else{
				changeItemState(item, 'done');
			}

			return;
		}
	}

	alert("didn't find an item with ticket id "+ticket);
}

function clickQueueItem(item, x, y){

	if (x >= 65 && x <= 76 && y >= 6 && y<=17){

		if (item.state == 'sending'){

			cancelItemSending(item);
		}

		removeItem(item);

		return;
	}

	if (item.state == 'done'){

		openUILinkIn("http://www.flickr.com/photo_edit.gne?id="+item.photoid, 'tab');

		return;
	}

	if (item.state == 'queued'){

		pauseQueueRunner();

		openDialog("chrome://flickrbar/content/edit.xul", "flickrEditWindow", "chrome, centerscreen, width=622, height=430, modal", item);

		unpauseQueueRunner();

		return;
	}

	if (item.state == 'sending' || item.state == 'waiting'){

		alert("You can't edit the photo details while it's uploading...");
	}
}

function pauseQueueRunner(){
	queue_runner_paused = 1;
}

function unpauseQueueRunner(){
	queue_runner_paused = 0;
	if (queue_is_waiting){
		drainQueue();
	}
}

function removeItem(item){

	//
	// remove it from the queue
	//

	var old_queue = upload_queue;
	upload_queue = [];

	for (var i=0; i<old_queue.length; i++){

		if (old_queue[i].id != item.id){

			upload_queue.push(old_queue[i]);
		}
	}

	destroyListItem(item);

	changeItemState(item, null);
}

function cancelItemSending(item){

	item.req.abort();
}

function showSettings(){

	var paneID = 'paneOne';

	var instantApply = getBoolPref("browser.preferences.instantApply", false);
	var features = "chrome, centerscreen, width=516, height=230, titlebar, toolbar" + (instantApply ? ", dialog=no" : ", modal");
	var features = "chrome, centerscreen, titlebar, toolbar" + (instantApply ? ", dialog=no" : ", modal");

	var wm = Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator);

	var win = wm.getMostRecentWindow("FlickrBar:Preferences");

	if (win) {
		win.focus();
		if (paneID) {
			var pane = win.document.getElementById(paneID);
			win.document.documentElement.showPane(pane);
		}
	}else{
		openDialog("chrome://flickrbar/content/settings.xul", "Preferences", features, paneID);
	}
}

function updateMiddleNav(){

	var showUploadLink = !waiting_for_upload && (state_counts.queued>0);
	var showClearLink = (state_counts.done>0);

	document.getElementById('middleNavUpload').style.display = ( showUploadLink && !showClearLink) ? 'block' : 'none';
	document.getElementById('middleNavClear' ).style.display = (!showUploadLink &&  showClearLink) ? 'block' : 'none';
	document.getElementById('middleNavBoth'  ).style.display = ( showUploadLink &&  showClearLink) ? 'block' : 'none';
}

function clearUploaded(){

	for (var i=upload_queue.length-1; i>=0; i--){

		if (upload_queue[i].state == 'done'){
			removeItem(upload_queue[i]);
		}
	}
}

function startUpload(){

	if (login_status == 'logged_out'){

		upload_once_loggged_in = 1;

		startLoginProcess();

		return;
	}

	if (login_status == 'logged_in'){

		drainQueue();

		return;
	}
}
