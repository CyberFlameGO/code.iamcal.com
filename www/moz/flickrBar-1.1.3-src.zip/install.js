const APP_NAME			= "Flickr Bar";
const APP_CHROME_NAME		= "flickrbar";
const APP_VERSION		= "1.1.3";
const APP_FILE 			= "flickrBar.jar";
const APP_CONTENTS_PATH		= "content/";
const APP_SKIN_PATH		= "skin/";
const APP_LOCALE_ENUS_PATH	= "locale/en-US/";

initInstall(APP_NAME, APP_CHROME_NAME, APP_VERSION); 

var chromeFolder = getFolder("Current User", "chrome");
setPackageFolder(chromeFolder);
addFile(APP_NAME, APP_FILE, chromeFolder, "");

var jarFolder = getFolder(chromeFolder, APP_FILE);
registerChrome(CONTENT	| PROFILE_CHROME, jarFolder, APP_CONTENTS_PATH);
registerChrome(SKIN	| PROFILE_CHROME, jarFolder, APP_SKIN_PATH);
registerChrome(LOCALE	| PROFILE_CHROME, jarFolder, APP_LOCALE_ENUS_PATH);

var result = getLastError(); 
if(result == SUCCESS) {
	performInstall();
} else {
	cancelInstall(result);
}
