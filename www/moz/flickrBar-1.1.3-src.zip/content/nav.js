
function navBarUpdateLoginStatus(){
	var status = getLoginStatus();

	if (status[0] == 'logged_out'){
		navBarSetLoggedOut();
	}

	if (status[0] == 'logged_in'){
		navBarSetLoggedIn(status[1]);
	}

	if (status[0] == 'checking'){
		navBarSetLoading();
	}
}

function navBarSetLoggedIn(name){

	var node = document.getElementById('navBarLoginName');

	node.replaceChild(document.createTextNode(name), node.childNodes[0]);

	document.getElementById('navBarLoading').style.display = 'none';
	document.getElementById('navBarLoggedOut').style.display = 'none';
	document.getElementById('navBarLoggedIn').style.display = 'block';
}

function navBarSetLoggedOut(){
	document.getElementById('navBarLoading').style.display = 'none';
	document.getElementById('navBarLoggedIn').style.display = 'none';
	document.getElementById('navBarLoggedOut').style.display = 'block';
}

function navBarSetLoading(){
	document.getElementById('navBarLoading').style.display = 'block';
	document.getElementById('navBarLoggedIn').style.display = 'none';
	document.getElementById('navBarLoggedOut').style.display = 'none';
}
