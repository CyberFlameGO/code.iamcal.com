var api_key = 'fe05adc26ff4ea6934c83a4ef2c8c1e7';
var api_secret = '2464e1f31f5ab587';

function bake_login_url(args){

	args = generate_sig(args);

	var params = generate_url_params(args);

	return 'http://flickr.com/services/auth/?'+params;
}

function api_get_frob(){

	var frob = null;

	var listener = {
		'flickr_auth_getFrob_onLoad': function(success, responseXML, responseText, params){

			if (success && responseXML){
				var frob_elm = responseXML.documentElement.getElementsByTagName('frob')[0];

				frob = frob_elm.childNodes[0].nodeValue;
			}
		}
	};
	flickrAPI.callMethod('flickr.auth.getFrob', {}, listener, 2, 1);

	return frob;
}

function api_get_token(frob){

	var out = {};

	var listener = {
		'flickr_auth_getToken_onLoad': function(success, responseXML, responseText, params){

			if (success && responseXML){

				var token_elm = responseXML.documentElement.getElementsByTagName('token')[0];
				var user_elm = responseXML.documentElement.getElementsByTagName('user')[0];

				out.user_id	= user_elm.getAttribute('nsid');
				out.user_name	= user_elm.getAttribute('username');
				out.token	= token_elm.childNodes[0].nodeValue;
			}
		}
	};
	flickrAPI.callMethod('flickr.auth.getToken', {'frob' : frob}, listener, 2, 1);

	return out;
}

function api_wait_for_ticket(ticket){

	var listener = {
		'flickr_photos_upload_checkTickets_onLoad': function(success, responseXML, responseText, params){

			if (success && responseXML){

				var ticket_elm = responseXML.documentElement.getElementsByTagName('ticket')[0];

				var complete = ticket_elm.getAttribute('complete');

				if (complete == 1){
					var photoid = ticket_elm.getAttribute('photoid');

					gotPhotoIdForTicket(ticket, photoid);
				}
				if (complete == 0){
					window.setTimeout(function(){ var aticket=ticket; api_wait_for_ticket(aticket); }, 1000);
				}
			}
		}
	};
	flickrAPI.callMethod('flickr.photos.upload.checkTickets', {'tickets': ticket}, listener, 1, 1);
}

function generate_sig(params){

	params.api_key = api_key;

	var params_keyA = [];
	for (var p in params) {
		params[p] = params[p];
		params_keyA.push(p);
	}

	params_keyA.sort();
	
	var calc = api_secret;

	for (var i=0;i<params_keyA.length;i++) {
		calc += params_keyA[i]+params[params_keyA[i]];
	}
	params.api_sig = hex_md5(calc);
		
	return params;
}

function generate_url_params(params){

	var bits = [];
	
	for (var p in params) {
		bits.push(p+'='+escape_utf8(params[p]));
	}

	return bits.join('&');
}

function escape_utf8(data){

	if (data == '' || data == null){
		return '';
	}
	data = data.toString();
	var buffer = '';
	for(var i=0; i<data.length; i++){
		var c = data.charCodeAt(i);
		var bs = new Array();

		if (c > 0x10000){
			// 4 bytes
			bs[0] = 0xF0 | ((c & 0x1C0000) >>> 18);
			bs[1] = 0x80 | ((c & 0x3F000) >>> 12);
			bs[2] = 0x80 | ((c & 0xFC0) >>> 6);
			bs[3] = 0x80 | (c & 0x3F);

		}else if (c > 0x800){
			// 3 bytes
			bs[0] = 0xE0 | ((c & 0xF000) >>> 12);
			bs[1] = 0x80 | ((c & 0xFC0) >>> 6);
			bs[2] = 0x80 | (c & 0x3F);

		}else if (c > 0x80){
			// 2 bytes
			bs[0] = 0xC0 | ((c & 0x7C0) >>> 6);
			bs[1] = 0x80 | (c & 0x3F);

		}else{
			// 1 byte
			bs[0] = c;
		}

		if (bs.length > 1){
			for(var j=0; j<bs.length; j++){
				var b = bs[j];
				var hex = nibble_to_hex((b & 0xF0) >>> 4) + nibble_to_hex(b & 0x0F);
				buffer += '%'+hex;
			}
		}else{
			buffer += encodeURIComponent(String.fromCharCode(bs[0]));
		}
	}

	return buffer;
}

function nibble_to_hex(nibble){
	var chars = '0123456789ABCDEF';
	return chars.charAt(nibble);
}

var flickrAPI = {};

flickrAPI.callMethod = function(APIMethod, params, listener, attempts, sync, delayMS) {

	if (typeof params != 'object') params = {}; // because we are going to stick a few things in even if no params are passed
	params.method = APIMethod; // see? And this also makes sure a method parameter is not passed
	
	var async = (sync) ? 0 : 1;
	
	var RESTURLROOT = 'http://www.flickr.com/services/rest/';

	params.cb = new Date().getTime();

	params = generate_sig(params);

	var RESTURL = generate_url_params(params);
		
	params.RESTURL = RESTURL; // again. we stick this in here because we pass params to the callback, and it might want to see the URL
	
	var attempts = (attempts == undefined) ? 1 : attempts;
	var req = new XMLHttpRequest();
	var unload_obj = {}
	
	if (req) {
		req.onreadystatechange = function() {
			if (req.readyState == 4) {
				if (req.responseText == '' && attempts<2) {
					attempts++;
					req.abort();
					flickrAPI.callMethod(APIMethod, params, listener, testingURL, attempts, server, async);
				} else {
					if (typeof flickrAPI == 'object') flickrAPI.handleResponse(req.responseXML, APIMethod, params, req.responseText, listener);
				}
			}
		}
		req.open('POST', RESTURLROOT, async);
		req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		
		if (async && delayMS) {

			setTimeout(
				function() {
					req.send(RESTURL);
				},
				delayMS
			);
			
		} else {
			try {
				req.send(RESTURL);
			}catch(e){}
		}
		if (!async) this.handleResponse(req.responseXML, APIMethod, params, req.responseText, listener);
	}
}

flickrAPI.getCallBackName = function (dotted) {
	return dotted.split('.').join('_')+'_onLoad';
}

flickrAPI.handleResponse = function(responseXML, APIMethod, params, responseText, listener) {
	if (!responseXML) { //OPERA!
		var success = (responseText.indexOf('stat="ok"') > -1) ? true : false;
	} else {
		var success = (responseXML.documentElement && responseXML.documentElement.getAttribute('stat') == 'ok') ? true : false;
	}
	listener = (listener) ? listener : this;
	listener[this.getCallBackName(APIMethod)](success, responseXML, responseText, params);
}
