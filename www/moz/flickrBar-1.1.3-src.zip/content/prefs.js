
function flickrBarGetPrefs(){

	var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
	var branch = prefs.getBranch("extensions.flickrbar.");
	return branch;
}

function flickrClearUserPref(name){
	try {
		return flickrBarGetPrefs().clearUserPref(name);
	}catch(e){}
	return null;
}

function flickrGetCharPref(name){
	try {
		return flickrBarGetPrefs().getCharPref(name);
	}catch(e){}
	return null;
}

function flickrSetCharPref(name, value){
	try {
		flickrBarGetPrefs().setCharPref(name, value);
	}catch(e){}
}

function flickrGetBoolPref(name){
	try {
		return flickrBarGetPrefs().getBoolPref(name);
	}catch(e){}
	return null;
}
