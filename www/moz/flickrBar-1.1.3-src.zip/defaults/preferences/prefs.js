
pref("extensions.flickrbar.is_public", true);
pref("extensions.flickrbar.is_friend", false);
pref("extensions.flickrbar.is_family", false);

pref("extensions.flickrbar.auto_upload", false);
pref("extensions.flickrbar.auto_clear", false);
