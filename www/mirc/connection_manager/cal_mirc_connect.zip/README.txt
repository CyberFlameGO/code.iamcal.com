cal's mirc connection manager
-----------------------------
(for managing alot of connections at once)


1. copy the connections.txt file into your mirc folder
2. edit the values in connections.txt
3. copy and paste the contents of script.txt into your remote window
4. enable person on connect, and add the following line for all groups:

/custom_perform

5. connect to a server or use the command /custom_startup to start the connection manager

--cal <cal@iamcal.com>
