a possible solution for the task posted here:
http://www.iamcal.com/topic_4429
