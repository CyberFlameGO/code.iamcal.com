//
// style switcher
// by cal henderson
//
// based on a script by Paul Sowden
// http://www.alistapart.com/stories/alternate/
//

// style sheet function

function setStyleSheet(title) {
	//alert("setting: "+title);
	for(var i = 0; i < document.getElementsByTagName("link").length; i++) {
		var a = document.getElementsByTagName("link")[i];
		if (a.getAttribute("rel") == "alternate stylesheet") {
			a.disabled = (a.getAttribute("title") == title)?false:true;
		}
	}
	createCookie("style", title, 365);
}

// cookie functions

function createCookie(name, value, days) {
	var date = new Date();
	date.setTime(date.getTime() + (days*24*60*60*1000));
	var expires = "; expires="+date.toGMTString();
	document.cookie = name + "=" + value + expires + "; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

// startup code

function init(){
	var cookie = readCookie("style");
	setStyleSheet(''); // to fix IE6 bug
	setStyleSheet((cookie)?cookie:'default');
}

init();
window.onload = init;
