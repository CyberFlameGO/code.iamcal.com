
add_product('item_0001', 'Product 1', 12.34);
add_product('item_0002', 'Product 2', 16.78);
add_product('item_0003', 'Product 3', 50.12);
add_product('item_0004', 'Product 4', 14.56);
add_product('item_0005', 'Product 5', 18.90);
