#define IDM_EXIT           100
