#define XAPPNAME "Generic"

#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>

#include "drag.h"


// Global Variables

HINSTANCE hInst;      // current instance
char szAppName[100];  // Name of the app
char szTitle[100];    // The title bar text
BOOL g_dragging = 0;
RECT g_dragrect;
HWND g_hWnd;
int counter_base = 0;
int counter = 0;


// Foward declarations of functions included in this code module:

ATOM MyRegisterClass(CONST WNDCLASS*);
BOOL InitApplication(HINSTANCE);
BOOL InitInstance(HINSTANCE, int);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK About(HWND, UINT, WPARAM, LPARAM);

void start_drag(int, int);
void stop_drag(void);
void move_drag(int, int);
void draw_dragrect(RECT);
void erase_dragrect(RECT);
RECT normalise_rect(RECT);
void CALLBACK ants_func(int, int, LPARAM);
void move_ants(void);


int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow){
	MSG msg;

	// Perform instance initialization:
	if (!InitApplication(hInstance)) {
		return (FALSE);
	}

	// Perform application initialization:
	if (!InitInstance(hInstance, nCmdShow)) {
		return (FALSE);
	}

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return ((int) msg.wParam);

	lpCmdLine; // This will prevent 'unused formal parameter' warnings
}


BOOL InitApplication(HINSTANCE hInstance) {
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = (WNDPROC)WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon (hInstance, "MAINICON");
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName  = "MAINMENU";
	wc.lpszClassName = "DRAGCLASS";

	return RegisterClass(&wc);
}


BOOL InitInstance(HINSTANCE hInstance, int nCmdShow) {
	hInst = hInstance; // Store instance handle in our global variable

	g_hWnd = CreateWindow("DRAGCLASS", "Drag App", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!g_hWnd) {
		return FALSE;
	}

	ShowWindow(g_hWnd, nCmdShow);
	UpdateWindow(g_hWnd);

	return TRUE;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message) {

		case WM_COMMAND:
			wmId    = LOWORD(wParam); // Remember, these are...
			wmEvent = HIWORD(wParam); // ...different for Win32!

			//Parse the menu selections:
			switch (wmId) {

				case IDM_EXIT:
					DestroyWindow (hWnd);
					break;

				default:
					return (DefWindowProc(hWnd, message, wParam, lParam));
			}
			break;

		case WM_LBUTTONDOWN:
			start_drag(LOWORD(lParam), HIWORD(lParam));
			break;

		case WM_LBUTTONUP:
			stop_drag();
			break;

		case WM_MOUSEMOVE:
			if (g_dragging) move_drag(LOWORD(lParam), HIWORD(lParam));
			break;

		case WM_TIMER:
			move_ants();
			break;

		case WM_PAINT:
			hdc = BeginPaint (hWnd, &ps);
			// Add any drawing code here...
			EndPaint (hWnd, &ps);
			break;

		case WM_DESTROY:
			PostQuitMessage(0);
			break;

		default:
			return (DefWindowProc(hWnd, message, wParam, lParam));
	}

	return (0);
}

void start_drag(int x, int y){
	g_dragging = 1;
	g_dragrect.left = g_dragrect.right = x;
	g_dragrect.top = g_dragrect.bottom = y;
	draw_dragrect(normalise_rect(g_dragrect));
	SetTimer(g_hWnd, 1, 200, NULL);
	SetCapture(g_hWnd);
}

void stop_drag(void){
	erase_dragrect(normalise_rect(g_dragrect));
	g_dragging = 0;
	ReleaseCapture();
	KillTimer(g_hWnd, 1);
}

void move_drag(int x, int y){
	erase_dragrect(normalise_rect(g_dragrect));
	g_dragrect.right = x;
	g_dragrect.bottom = y;
	draw_dragrect(normalise_rect(g_dragrect));
}

void draw_dragrect(RECT r){
	HDC hdc;

	hdc = GetDC(g_hWnd);

	counter = counter_base;
	LineDDA(r.left, r.top, r.right, r.top, (LINEDDAPROC)ants_func, (LPARAM)hdc);
	LineDDA(r.right, r.top, r.right, r.bottom, (LINEDDAPROC)ants_func, (LPARAM)hdc);
	LineDDA(r.right, r.bottom, r.left, r.bottom, (LINEDDAPROC)ants_func, (LPARAM)hdc);
	LineDDA(r.left, r.bottom, r.left, r.top, (LINEDDAPROC)ants_func, (LPARAM)hdc);

	ReleaseDC(g_hWnd, hdc);
}

void erase_dragrect(RECT r){
	InflateRect(&r, 1, 1);
	InvalidateRect(g_hWnd, &r, TRUE);
	InflateRect(&r, -2, -2);
	ValidateRect(g_hWnd, &r);
	UpdateWindow(g_hWnd);
}

RECT normalise_rect(RECT r){
	RECT r2;
	LONG temp;

	r2 = r;
	if (r2.left > r2.right){
		temp = r2.left;
		r2.left = r2.right;
		r2.right = temp;
	}
	if (r2.top > r2.bottom){
		temp = r2.top;
		r2.top = r2.bottom;
		r2.bottom = temp;
	}

	return r2;
}

void move_ants(void){
	if (g_dragging){
		counter_base += 3;
		counter_base %= 8;
		erase_dragrect(normalise_rect(g_dragrect));
		draw_dragrect(normalise_rect(g_dragrect));
	}
}

void CALLBACK ants_func(int x, int y, LPARAM lpData){
	HDC hdc = (HDC)lpData;
	counter++;
	counter %= 8;
	if (counter < 5) SetPixel(hdc, x, y, RGB(0xff,0,0));
}